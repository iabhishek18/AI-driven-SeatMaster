"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  MapPin,
  Star,
  Users,
  Wifi,
  Coffee,
  ParkingMeterIcon as Parking,
  Accessibility,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  ImageIcon,
  Map,
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"
import { cn } from "@/lib/utils"
import PanoramaViewer from "./panorama-viewer"

// Define venue data structure
export interface VenueDetails {
  id: string
  name: string
  address: string
  description: string
  rating: number
  capacity: string
  amenities: string[]
  images: string[]
  panoramas?: string[]
  mapUrl?: string
  mapEmbed?: string
  virtualTourUrl?: string
}

// Mock venue data based on venue names
const venueData: Record<string, VenueDetails> = {
  "AMC Theaters": {
    id: "venue-1",
    name: "AMC Theaters",
    address: "234 Broadway, New York, NY 10001",
    description: "A premium cinema experience with state-of-the-art sound systems and comfortable seating.",
    rating: 4.7,
    capacity: "300 seats",
    amenities: ["IMAX", "Dolby Atmos", "Recliner Seats", "Food Service", "Wheelchair Access", "Wifi"],
    images: [
      "/classic-movie-theater.png",
      "/placeholder.svg?height=800&width=1200&query=movie%20theater%20seats",
      "/placeholder.svg?height=800&width=1200&query=cinema%20lobby",
      "/placeholder.svg?height=800&width=1200&query=movie%20theater%20screen",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20movie%20theater%20interior",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20cinema%20lobby",
    ],
    mapUrl: "https://maps.google.com/?q=AMC+Theaters+New+York",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.9663095343077!2d-73.99038388459468!3d40.74127797932825!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259a9aeb1c6b5%3A0x35b1cfbc89a6097f!2sAMC%2034th%20Street%2014!5e0!3m2!1sen!2sus!4v1653060799574!5m2!1sen!2sus",
  },
  "Staples Center": {
    id: "venue-2",
    name: "Staples Center",
    address: "1111 S Figueroa St, Los Angeles, CA 90015",
    description: "Home to the Los Angeles Lakers and host to major sporting events and concerts.",
    rating: 4.8,
    capacity: "20,000 seats",
    amenities: ["VIP Boxes", "Food Courts", "Merchandise Shops", "Parking", "Wheelchair Access", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=staples%20center%20arena",
      "/placeholder.svg?height=800&width=1200&query=basketball%20stadium%20court",
      "/placeholder.svg?height=800&width=1200&query=staples%20center%20exterior",
      "/placeholder.svg?height=800&width=1200&query=concert%20arena%20crowd",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20basketball%20arena",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20staples%20center%20court",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20concert%20venue",
    ],
    mapUrl: "https://maps.google.com/?q=Staples+Center",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3305.7152860671257!2d-118.26978368477933!3d34.043018880608685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2c7b85dea2a93%3A0x1ff47c3ceb7bb2d5!2sCrypto.com%20Arena!5e0!3m2!1sen!2sus!4v1653060892574!5m2!1sen!2sus",
    virtualTourUrl: "#virtual-tour",
  },
  "Madison Square Garden": {
    id: "venue-3",
    name: "Madison Square Garden",
    address: "4 Pennsylvania Plaza, New York, NY 10001",
    description: "The world's most famous arena, hosting concerts, sporting events, and more.",
    rating: 4.9,
    capacity: "20,789 seats",
    amenities: ["Premium Seating", "Multiple Bars", "Restaurants", "Merchandise", "Accessibility", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=madison%20square%20garden%20concert",
      "/placeholder.svg?height=800&width=1200&query=msg%20arena%20interior",
      "/placeholder.svg?height=800&width=1200&query=madison%20square%20garden%20exterior",
      "/placeholder.svg?height=800&width=1200&query=basketball%20court%20msg",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20madison%20square%20garden",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20concert%20arena",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20basketball%20court",
    ],
    mapUrl: "https://maps.google.com/?q=Madison+Square+Garden",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.2737569197404!2d-73.99566768459407!3d40.75050197932766!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a21fb011c85%3A0x33df10f2a9e2c0!2sMadison%20Square%20Garden!5e0!3m2!1sen!2sus!4v1653060952574!5m2!1sen!2sus",
    virtualTourUrl: "#virtual-tour",
  },
  "Grand Central Station": {
    id: "venue-4",
    name: "Grand Central Station",
    address: "89 E 42nd St, New York, NY 10017",
    description: "Historic train terminal with stunning architecture and convenient transportation connections.",
    rating: 4.6,
    capacity: "High volume transit hub",
    amenities: ["Dining Options", "Shopping", "Information Desk", "Waiting Areas", "Accessibility", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=grand%20central%20terminal%20main%20concourse",
      "/placeholder.svg?height=800&width=1200&query=grand%20central%20station%20ceiling",
      "/placeholder.svg?height=800&width=1200&query=grand%20central%20terminal%20exterior",
      "/placeholder.svg?height=800&width=1200&query=train%20platform%20grand%20central",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20grand%20central%20terminal",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20train%20station%20concourse",
    ],
    mapUrl: "https://maps.google.com/?q=Grand+Central+Terminal",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.3932328660354!2d-73.97918768459416!3d40.75272297932752!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a21fb011c85%3A0x37513b7f1821408b!2sGrand%20Central%20Terminal!5e0!3m2!1sen!2sus!4v1653061012574!5m2!1sen!2sus",
  },
  "IMAX Theater": {
    id: "venue-5",
    name: "IMAX Theater",
    address: "550 Lincoln Road, Miami Beach, FL 33139",
    description: "Premium large-format cinema experience with crystal-clear images and precision sound.",
    rating: 4.8,
    capacity: "400 seats",
    amenities: ["IMAX Projection", "Premium Sound", "Luxury Seating", "Concessions", "Accessibility", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=imax%20theater%20screen",
      "/placeholder.svg?height=800&width=1200&query=imax%20cinema%20seats",
      "/placeholder.svg?height=800&width=1200&query=imax%20theater%20exterior",
      "/placeholder.svg?height=800&width=1200&query=imax%20projector",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20imax%20theater",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20cinema%20auditorium",
    ],
    mapUrl: "https://maps.google.com/?q=IMAX+Theater+Miami",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3592.9974440601246!2d-80.13427768516!3d25.78701998362641!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88d9b485c54138e9%3A0x9e4aa9c54c2b9c77!2sRegal%20South%20Beach%20IMAX!5e0!3m2!1sen!2sus!4v1653061072574!5m2!1sen!2sus",
  },
  "Central Bus Terminal": {
    id: "venue-6",
    name: "Central Bus Terminal",
    address: "625 8th Avenue, New York, NY 10018",
    description: "Major bus terminal serving intercity routes with modern facilities and amenities.",
    rating: 4.2,
    capacity: "High volume transit hub",
    amenities: ["Waiting Areas", "Food Court", "Restrooms", "Ticket Counters", "Information Desk", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=bus%20terminal%20interior",
      "/placeholder.svg?height=800&width=1200&query=bus%20station%20waiting%20area",
      "/placeholder.svg?height=800&width=1200&query=bus%20terminal%20exterior",
      "/placeholder.svg?height=800&width=1200&query=bus%20departure%20gates",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20bus%20terminal",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20bus%20station%20concourse",
    ],
    mapUrl: "https://maps.google.com/?q=Port+Authority+Bus+Terminal",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.1494411689!2d-73.99261768459398!3d40.75682797932728!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25854f7a4e4d1%3A0x7c94b89a68171a9a!2sPort%20Authority%20Bus%20Terminal!5e0!3m2!1sen!2sus!4v1653061132574!5m2!1sen!2sus",
  },
  "Union Station": {
    id: "venue-7",
    name: "Union Station",
    address: "225 S Canal St, Chicago, IL 60606",
    description: "Historic train station with beautiful architecture and modern amenities.",
    rating: 4.5,
    capacity: "High volume transit hub",
    amenities: ["Waiting Lounges", "Restaurants", "Shops", "Baggage Services", "Accessibility", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=chicago%20union%20station%20great%20hall",
      "/placeholder.svg?height=800&width=1200&query=union%20station%20chicago%20interior",
      "/placeholder.svg?height=800&width=1200&query=union%20station%20exterior%20chicago",
      "/placeholder.svg?height=800&width=1200&query=train%20platforms%20union%20station",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20union%20station%20chicago",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20train%20station%20hall",
    ],
    mapUrl: "https://maps.google.com/?q=Union+Station+Chicago",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2970.6592307485584!2d-87.64163768454642!3d41.87872797922127!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880e2d2e1f213097%3A0x5f7f65cf00d2f5ca!2sChicago%20Union%20Station!5e0!3m2!1sen!2sus!4v1653061192574!5m2!1sen!2sus",
  },
  "Port Authority": {
    id: "venue-8",
    name: "Port Authority",
    address: "625 8th Avenue, New York, NY 10018",
    description: "The main gateway for interstate buses into Manhattan with comprehensive facilities.",
    rating: 4.0,
    capacity: "High volume transit hub",
    amenities: ["Waiting Areas", "Food Court", "Restrooms", "Ticket Counters", "Information Desk", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=port%20authority%20bus%20terminal%20interior",
      "/placeholder.svg?height=800&width=1200&query=bus%20station%20waiting%20area",
      "/placeholder.svg?height=800&width=1200&query=port%20authority%20exterior%20nyc",
      "/placeholder.svg?height=800&width=1200&query=bus%20departure%20gates",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20port%20authority%20terminal",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20bus%20station",
    ],
    mapUrl: "https://maps.google.com/?q=Port+Authority+Bus+Terminal",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.1494411689!2d-73.99261768459398!3d40.75682797932728!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25854f7a4e4d1%3A0x7c94b89a68171a9a!2sPort%20Authority%20Bus%20Terminal!5e0!3m2!1sen!2sus!4v1653061132574!5m2!1sen!2sus",
  },
  "Regal Cinemas": {
    id: "venue-9",
    name: "Regal Cinemas",
    address: "850 Broadway, New York, NY 10003",
    description: "Modern multiplex cinema with the latest releases and comfortable viewing experience.",
    rating: 4.5,
    capacity: "250 seats per theater",
    amenities: ["Multiple Screens", "Dolby Sound", "Concessions", "Arcade", "Accessibility", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=regal%20cinemas%20interior",
      "/placeholder.svg?height=800&width=1200&query=movie%20theater%20lobby%20concessions",
      "/placeholder.svg?height=800&width=1200&query=cinema%20exterior%20night",
      "/placeholder.svg?height=800&width=1200&query=movie%20theater%20seats%20modern",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20movie%20theater",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20cinema%20lobby",
    ],
    mapUrl: "https://maps.google.com/?q=Regal+Cinemas+New+York",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3023.0553146255686!2d-73.99238768459476!3d40.73968797932835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259998510b0c5%3A0x4b49b9e1c9cd67e1!2sRegal%20Union%20Square!5e0!3m2!1sen!2sus!4v1653061252574!5m2!1sen!2sus",
  },
  "Penn Station": {
    id: "venue-10",
    name: "Penn Station",
    address: "Penn Station, New York, NY 10001",
    description: "Major transportation hub serving Amtrak, Long Island Rail Road, and NJ Transit.",
    rating: 4.2,
    capacity: "High volume transit hub",
    amenities: ["Waiting Areas", "Food Court", "Ticket Counters", "Information Desk", "Accessibility", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=penn%20station%20interior%20nyc",
      "/placeholder.svg?height=800&width=1200&query=penn%20station%20waiting%20area",
      "/placeholder.svg?height=800&width=1200&query=penn%20station%20entrance",
      "/placeholder.svg?height=800&width=1200&query=train%20platform%20penn%20station",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20penn%20station",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20train%20concourse",
    ],
    mapUrl: "https://maps.google.com/?q=Penn+Station+New+York",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.4828391826!2d-73.99517768459425!3d40.75058797932764!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c259ae15b2adcb%3A0x7955420634fd7eba!2sPenn%20Station!5e0!3m2!1sen!2sus!4v1653061312574!5m2!1sen!2sus",
  },
  "MetLife Stadium": {
    id: "venue-12",
    name: "MetLife Stadium",
    address: "1 MetLife Stadium Dr, East Rutherford, NJ 07073",
    description: "Home of the New York Giants and Jets, and host to major concerts and events.",
    rating: 4.7,
    capacity: "82,500 seats",
    amenities: ["VIP Suites", "Food Courts", "Merchandise Shops", "Parking", "Accessibility", "Wifi"],
    images: [
      "/placeholder.svg?height=800&width=1200&query=metlife%20stadium%20aerial%20view",
      "/placeholder.svg?height=800&width=1200&query=metlife%20stadium%20field",
      "/placeholder.svg?height=800&width=1200&query=metlife%20stadium%20exterior",
      "/placeholder.svg?height=800&width=1200&query=metlife%20stadium%20concert",
    ],
    panoramas: [
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20football%20stadium",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20metlife%20stadium",
      "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20stadium%20concert",
    ],
    mapUrl: "https://maps.google.com/?q=MetLife+Stadium",
    mapEmbed:
      "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3018.103281771386!2d-74.07981768459033!3d40.81372797932394!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2f861ad4e8643%3A0x2e1c596851b1c7aa!2sMetLife%20Stadium!5e0!3m2!1sen!2sus!4v1653061372574!5m2!1sen!2sus",
    virtualTourUrl: "#virtual-tour",
  },
}

// Default venue details for venues not in our database
const defaultVenueDetails: VenueDetails = {
  id: "default",
  name: "Venue",
  address: "123 Main St, City, State 12345",
  description: "A wonderful venue with great facilities and amenities.",
  rating: 4.5,
  capacity: "Varies",
  amenities: ["Seating", "Restrooms", "Concessions", "Wifi"],
  images: [
    "/placeholder.svg?height=800&width=1200&query=event%20venue%20interior",
    "/placeholder.svg?height=800&width=1200&query=event%20venue%20exterior",
    "/placeholder.svg?height=800&width=1200&query=venue%20seating",
    "/placeholder.svg?height=800&width=1200&query=venue%20stage",
  ],
  panoramas: [
    "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20event%20venue",
    "/placeholder.svg?height=2000&width=4000&query=360%20panorama%20concert%20hall",
  ],
  mapEmbed:
    "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.1494411689!2d-73.99261768459398!3d40.75682797932728!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25854f7a4e4d1%3A0x7c94b89a68171a9a!2sNew+York!5e0!3m2!1sen!2sus!4v1653061132574!5m2!1sen!2sus",
}

interface VenuePreviewProps {
  venueName: string
  isOpen: boolean
  onClose: () => void
}

// Create a custom View360 icon
const View360Icon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="10" />
    <circle cx="12" cy="12" r="4" />
    <line x1="21.17" y1="8" x2="12" y2="8" />
    <line x1="3.95" y1="6.06" x2="8.54" y2="14" />
    <line x1="10.88" y1="21.94" x2="15.46" y2="14" />
  </svg>
)

export default function VenuePreview({ venueName, isOpen, onClose }: VenuePreviewProps) {
  const [activeImageIndex, setActiveImageIndex] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const [imagesLoaded, setImagesLoaded] = useState<boolean[]>([])
  const [activeTab, setActiveTab] = useState<"photos" | "map" | "360">("photos")

  // Get venue details from our database or use default
  const venueDetails = venueData[venueName] || { ...defaultVenueDetails, name: venueName }

  // Reset loading state when venue changes
  useEffect(() => {
    setIsLoading(true)
    setActiveImageIndex(0)
    setImagesLoaded(new Array(venueDetails.images.length).fill(false))
    setActiveTab("photos")
  }, [venueName, venueDetails.images.length])

  // Handle image load
  const handleImageLoad = (index: number) => {
    const newImagesLoaded = [...imagesLoaded]
    newImagesLoaded[index] = true
    setImagesLoaded(newImagesLoaded)

    // If the active image is loaded, set loading to false
    if (index === activeImageIndex) {
      setIsLoading(false)
    }
  }

  // Navigate to next image
  const nextImage = () => {
    setActiveImageIndex((prev) => (prev + 1) % venueDetails.images.length)
    setIsLoading(!imagesLoaded[(activeImageIndex + 1) % venueDetails.images.length])
  }

  // Navigate to previous image
  const prevImage = () => {
    setActiveImageIndex((prev) => (prev - 1 + venueDetails.images.length) % venueDetails.images.length)
    setIsLoading(!imagesLoaded[(activeImageIndex - 1 + venueDetails.images.length) % venueDetails.images.length])
  }

  const amenityIcons: Record<string, React.ReactNode> = {
    Wifi: <Wifi className="h-4 w-4" />,
    "Food Service": <Coffee className="h-4 w-4" />,
    "Food Court": <Coffee className="h-4 w-4" />,
    Concessions: <Coffee className="h-4 w-4" />,
    Restaurants: <Coffee className="h-4 w-4" />,
    "Dining Options": <Coffee className="h-4 w-4" />,
    Parking: <Parking className="h-4 w-4" />,
    "Wheelchair Access": <Accessibility className="h-4 w-4" />,
    Accessibility: <Accessibility className="h-4 w-4" />,
  }

  // Check if venue has panoramas
  const hasPanoramas = venueDetails.panoramas && venueDetails.panoramas.length > 0

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto p-0">
        {/* Venue Header */}
        <div className="p-6 pb-0">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-4">
            <div>
              <h2 className="text-2xl font-bold mb-1">{venueDetails.name}</h2>
              <p className="text-muted-foreground flex items-center">
                <MapPin className="h-4 w-4 mr-1 text-primary" />
                {venueDetails.address}
              </p>
            </div>

            <div className="flex items-center gap-2 mt-2 sm:mt-0">
              <Badge variant="outline" className="flex items-center gap-1 py-1.5">
                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                {venueDetails.rating}
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1 py-1.5">
                <Users className="h-4 w-4" />
                {venueDetails.capacity}
              </Badge>
            </div>
          </div>

          {/* Tabs for Photos, 360° Tour, and Map */}
          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "photos" | "map" | "360")}>
            <TabsList className={`grid w-full ${hasPanoramas ? "grid-cols-3" : "grid-cols-2"} mb-4 cursor-pointer`}>
              <TabsTrigger value="photos" className="flex items-center gap-2 cursor-pointer">
                <ImageIcon className="h-4 w-4" />
                Photos
              </TabsTrigger>
              {hasPanoramas && (
                <TabsTrigger value="360" className="flex items-center gap-2 cursor-pointer">
                  <View360Icon />
                  360° Tour
                </TabsTrigger>
              )}
              <TabsTrigger value="map" className="flex items-center gap-2 cursor-pointer">
                <Map className="h-4 w-4" />
                Map
              </TabsTrigger>
            </TabsList>

            <TabsContent value="photos" className="mt-0">
              {/* Image Gallery */}
              <div className="relative w-full h-[300px] sm:h-[400px] overflow-hidden rounded-md">
                {/* Loading Overlay */}
                <AnimatePresence>
                  {isLoading && (
                    <motion.div
                      className="absolute inset-0 bg-black/50 z-10 flex items-center justify-center"
                      initial={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Image Gallery */}
                <div className="relative h-full w-full">
                  {venueDetails.images.map((image, index) => (
                    <div
                      key={index}
                      className={`absolute inset-0 transition-opacity duration-500 ${
                        index === activeImageIndex ? "opacity-100 z-0" : "opacity-0 -z-10"
                      }`}
                    >
                      <Image
                        src={image || "/placeholder.svg"}
                        alt={`${venueDetails.name} - Image ${index + 1}`}
                        fill
                        className="object-cover"
                        priority={index === 0}
                        onLoad={() => handleImageLoad(index)}
                      />
                    </div>
                  ))}
                </div>

                {/* Navigation Controls */}
                <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-4 z-20">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-10 w-10 rounded-full bg-black/30 text-white hover:bg-black/50 cursor-pointer"
                    onClick={prevImage}
                    aria-label="Previous image"
                  >
                    <ChevronLeft className="h-6 w-6" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-10 w-10 rounded-full bg-black/30 text-white hover:bg-black/50 cursor-pointer"
                    onClick={nextImage}
                    aria-label="Next image"
                  >
                    <ChevronRight className="h-6 w-6" />
                  </Button>
                </div>

                {/* Image Counter */}
                <div className="absolute bottom-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm z-20">
                  {activeImageIndex + 1} / {venueDetails.images.length}
                </div>
              </div>

              {/* Thumbnails */}
              <div className="grid grid-cols-4 gap-2 mt-4">
                {venueDetails.images.map((image, index) => (
                  <button
                    key={index}
                    className={cn(
                      "relative h-16 sm:h-20 w-full rounded-md overflow-hidden cursor-pointer transition-all",
                      index === activeImageIndex ? "ring-2 ring-primary" : "hover:opacity-80",
                    )}
                    onClick={() => {
                      setActiveImageIndex(index)
                      setIsLoading(!imagesLoaded[index])
                    }}
                  >
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`Thumbnail ${index + 1}`}
                      fill
                      className="object-cover"
                    />
                  </button>
                ))}
              </div>
            </TabsContent>

            {hasPanoramas && (
              <TabsContent value="360" className="mt-0">
                {/* 360° Panorama Viewer */}
                <PanoramaViewer images={venueDetails.panoramas || []} />
                <div className="mt-4 text-sm text-muted-foreground text-center">
                  <p>Drag to look around • Use mouse wheel or pinch to zoom • Click and hold to move</p>
                </div>
              </TabsContent>
            )}

            <TabsContent value="map" className="mt-0">
              {/* Embedded Map */}
              <div className="w-full h-[400px] rounded-md overflow-hidden">
                <iframe
                  src={venueDetails.mapEmbed}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title={`Map of ${venueDetails.name}`}
                ></iframe>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Content Section */}
        <div className="p-6 pt-0">
          {/* Description */}
          <div className="mb-6 mt-4">
            <h3 className="text-lg font-semibold mb-2">About</h3>
            <p className="text-muted-foreground">{venueDetails.description}</p>
          </div>

          {/* Amenities */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Amenities</h3>
            <div className="flex flex-wrap gap-2">
              {venueDetails.amenities.map((amenity) => (
                <Badge key={amenity} variant="outline" className="flex items-center gap-1 py-1.5">
                  {amenityIcons[amenity] || null}
                  {amenity}
                </Badge>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-6">
            {venueDetails.mapUrl && (
              <Button
                variant="outline"
                className="w-full justify-center items-center gap-2 cursor-pointer"
                onClick={() => window.open(venueDetails.mapUrl, "_blank")}
              >
                <MapPin className="h-4 w-4" />
                View on Google Maps
                <ExternalLink className="h-3 w-3 ml-1 opacity-70" />
              </Button>
            )}

            {venueDetails.virtualTourUrl && (
              <Button
                variant="outline"
                className="w-full justify-center items-center gap-2 cursor-pointer"
                onClick={() => window.open(venueDetails.virtualTourUrl, "_blank")}
              >
                <View360Icon />
                External Virtual Tour
                <ExternalLink className="h-3 w-3 ml-1 opacity-70" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
