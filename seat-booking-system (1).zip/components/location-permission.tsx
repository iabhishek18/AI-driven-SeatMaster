"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { MapPin, Shield, AlertTriangle, CheckCircle, XCircle } from "lucide-react"
import { geolocationService, type LocationPermissionStatus } from "@/lib/geolocation-service"

interface LocationPermissionProps {
  onPermissionGranted?: () => void
  onPermissionDenied?: () => void
  showCard?: boolean
}

export default function LocationPermission({
  onPermissionGranted,
  onPermissionDenied,
  showCard = true,
}: LocationPermissionProps) {
  const [permissionStatus, setPermissionStatus] = useState<LocationPermissionStatus>({
    granted: false,
    denied: false,
    prompt: true,
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    checkPermissionStatus()
  }, [])

  const checkPermissionStatus = async () => {
    try {
      const status = await geolocationService.getPermissionStatus()
      setPermissionStatus(status)
    } catch (error) {
      console.error("Failed to check permission status:", error)
    }
  }

  const requestPermission = async () => {
    setIsLoading(true)
    setError(null)

    try {
      await geolocationService.getCurrentLocation()
      const newStatus = await geolocationService.getPermissionStatus()
      setPermissionStatus(newStatus)

      if (newStatus.granted && onPermissionGranted) {
        onPermissionGranted()
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to get location"
      setError(errorMessage)

      if (errorMessage.includes("denied") && onPermissionDenied) {
        onPermissionDenied()
      }
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusIcon = () => {
    if (permissionStatus.granted) {
      return <CheckCircle className="h-5 w-5 text-green-500" />
    } else if (permissionStatus.denied) {
      return <XCircle className="h-5 w-5 text-red-500" />
    } else {
      return <AlertTriangle className="h-5 w-5 text-yellow-500" />
    }
  }

  const getStatusText = () => {
    if (permissionStatus.granted) {
      return "Location access granted"
    } else if (permissionStatus.denied) {
      return "Location access denied"
    } else {
      return "Location permission required"
    }
  }

  const getStatusDescription = () => {
    if (permissionStatus.granted) {
      return "We can show you nearby events and venues based on your location."
    } else if (permissionStatus.denied) {
      return "To enable location features, please allow location access in your browser settings."
    } else {
      return "Allow location access to find nearby events and get personalized recommendations."
    }
  }

  if (!geolocationService.isSupported()) {
    return (
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>Geolocation is not supported by your browser.</AlertDescription>
      </Alert>
    )
  }

  const content = (
    <div className="space-y-4">
      <div className="flex items-center space-x-3">
        {getStatusIcon()}
        <div>
          <h3 className="font-medium">{getStatusText()}</h3>
          <p className="text-sm text-muted-foreground">{getStatusDescription()}</p>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {!permissionStatus.granted && (
        <div className="space-y-3">
          <Button onClick={requestPermission} disabled={isLoading} className="w-full">
            <MapPin className="mr-2 h-4 w-4" />
            {isLoading ? "Requesting Permission..." : "Enable Location Services"}
          </Button>

          <div className="text-xs text-muted-foreground space-y-1">
            <div className="flex items-center space-x-2">
              <Shield className="h-3 w-3" />
              <span>Your location data is kept private and secure</span>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-3 w-3" />
              <span>Used only to show nearby events and venues</span>
            </div>
          </div>
        </div>
      )}

      {permissionStatus.denied && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            To enable location features, please:
            <ol className="list-decimal list-inside mt-2 space-y-1">
              <li>Click the location icon in your browser's address bar</li>
              <li>Select "Allow" for location access</li>
              <li>Refresh the page</li>
            </ol>
          </AlertDescription>
        </Alert>
      )}
    </div>
  )

  if (!showCard) {
    return content
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <MapPin className="h-5 w-5" />
          <span>Location Services</span>
        </CardTitle>
        <CardDescription>Enable location access to discover nearby events and venues</CardDescription>
      </CardHeader>
      <CardContent>{content}</CardContent>
    </Card>
  )
}
