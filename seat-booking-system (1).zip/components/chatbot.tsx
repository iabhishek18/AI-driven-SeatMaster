"use client"

import type React from "react"

import { useState, useRef, useEffect, useCallback } from "react"
import { MessageSquare, X, Send, Minimize2, Maximize2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Avatar } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { initialEvents } from "@/data/initial-data"
import { busRoutes, trainRoutes } from "@/data/transport-data"
import { aiService } from "@/lib/ai-service"

// Define types for our data structures to help with type safety
type Event = (typeof initialEvents)[0]
type BusRoute = (typeof busRoutes)[0]
type TrainRoute = (typeof trainRoutes)[0]

type Message = {
  id: string
  content: string
  sender: "user" | "bot"
  timestamp: Date
  suggestedReplies?: string[]
}

type ConversationContext = {
  lastMentionedEvent?: Event
  lastMentionedBus?: BusRoute
  lastMentionedTrain?: TrainRoute
  lastTopic?: "events" | "buses" | "trains" | "booking" | "general"
  searchResults?: Array<Event | BusRoute | TrainRoute>
  userPreferences?: {
    preferredTransport?: "bus" | "train"
    preferredEventType?: string
    priceRange?: { min: number; max: number }
  }
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "👋 Hi there! I'm your virtual assistant. I can answer questions about events, transportation options, and bookings on this site. How can I help you today?",
      sender: "bot",
      timestamp: new Date(),
      suggestedReplies: [
        "What events are available?",
        "Tell me about transportation options",
        "How do I book tickets?",
      ],
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [context, setContext] = useState<ConversationContext>({})
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Load chat history from localStorage on initial load
  useEffect(() => {
    const savedMessages = localStorage.getItem("chatHistory")
    if (savedMessages) {
      try {
        const parsedMessages = JSON.parse(savedMessages).map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp),
        }))
        setMessages(parsedMessages)
      } catch (error) {
        console.error("Failed to parse saved chat history:", error)
      }
    }
  }, [])

  // Save chat history to localStorage when messages change
  useEffect(() => {
    if (messages.length > 1) {
      localStorage.setItem("chatHistory", JSON.stringify(messages))
    }
  }, [messages])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = useCallback(() => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Track chatbot interaction
    aiService.trackUserBehavior("chatbot_interaction", {
      query: inputValue,
      timestamp: Date.now(),
    })

    // Process the message and update context
    const updatedContext = analyzeUserQuery(inputValue, context)
    setContext(updatedContext)

    // Simulate bot thinking
    setTimeout(
      () => {
        const { response, suggestedReplies, newContext } = generateEnhancedResponse(inputValue, updatedContext)

        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: response,
          sender: "bot",
          timestamp: new Date(),
          suggestedReplies,
        }

        setMessages((prev) => [...prev, botMessage])
        setContext(newContext)
        setIsTyping(false)
      },
      Math.random() * 1000 + 500,
    ) // Random delay between 500-1500ms for more natural feel
  }, [inputValue, context])

  // Analyze user query to extract entities and update context
  const analyzeUserQuery = (query: string, currentContext: ConversationContext): ConversationContext => {
    const normalizedQuery = query.toLowerCase()
    const newContext = { ...currentContext }

    // Detect topic
    if (
      normalizedQuery.includes("event") ||
      normalizedQuery.includes("show") ||
      normalizedQuery.includes("movie") ||
      normalizedQuery.includes("concert") ||
      normalizedQuery.includes("game")
    ) {
      newContext.lastTopic = "events"

      // Try to identify specific event
      for (const event of initialEvents) {
        if (normalizedQuery.includes(event.name.toLowerCase())) {
          newContext.lastMentionedEvent = event
          break
        }
      }

      // Extract event type preferences
      if (normalizedQuery.includes("movie") || normalizedQuery.includes("cinema")) {
        newContext.userPreferences = {
          ...newContext.userPreferences,
          preferredEventType: "cinema",
        }
      } else if (normalizedQuery.includes("concert") || normalizedQuery.includes("music")) {
        newContext.userPreferences = {
          ...newContext.userPreferences,
          preferredEventType: "general", // Using general for concerts in our mock data
        }
      } else if (
        normalizedQuery.includes("sport") ||
        normalizedQuery.includes("game") ||
        normalizedQuery.includes("match")
      ) {
        newContext.userPreferences = {
          ...newContext.userPreferences,
          preferredEventType: "general", // Using general for sports in our mock data
        }
      }
    } else if (normalizedQuery.includes("bus")) {
      newContext.lastTopic = "buses"
      newContext.userPreferences = {
        ...newContext.userPreferences,
        preferredTransport: "bus",
      }

      // Try to identify specific bus route
      for (const bus of busRoutes) {
        if (
          normalizedQuery.includes(bus.busNumber.toLowerCase()) ||
          normalizedQuery.includes(bus.operator.toLowerCase())
        ) {
          newContext.lastMentionedBus = bus
          break
        }
      }
    } else if (normalizedQuery.includes("train")) {
      newContext.lastTopic = "trains"
      newContext.userPreferences = {
        ...newContext.userPreferences,
        preferredTransport: "train",
      }

      // Try to identify specific train route
      for (const train of trainRoutes) {
        if (
          normalizedQuery.includes(train.trainNumber.toLowerCase()) ||
          normalizedQuery.includes(train.trainName.toLowerCase())
        ) {
          newContext.lastMentionedTrain = train
          break
        }
      }
    } else if (
      normalizedQuery.includes("book") ||
      normalizedQuery.includes("reservation") ||
      normalizedQuery.includes("ticket") ||
      normalizedQuery.includes("seat")
    ) {
      newContext.lastTopic = "booking"
    }

    // Extract price range preferences
    const priceMatch = normalizedQuery.match(/(\$\d+|\d+ dollars)/g)
    if (priceMatch && priceMatch.length > 0) {
      const prices = priceMatch.map((p) => Number.parseInt(p.replace(/\$|\s|dollars/g, "")))
      if (prices.length === 1) {
        newContext.userPreferences = {
          ...newContext.userPreferences,
          priceRange: { min: 0, max: prices[0] },
        }
      } else if (prices.length >= 2) {
        const sortedPrices = [...prices].sort((a, b) => a - b)
        newContext.userPreferences = {
          ...newContext.userPreferences,
          priceRange: { min: sortedPrices[0], max: sortedPrices[sortedPrices.length - 1] },
        }
      }
    }

    // Extract location information
    const cities = ["New York", "Boston", "Philadelphia", "Chicago", "Washington DC", "Las Vegas", "Atlantic City"]
    for (const city of cities) {
      if (normalizedQuery.includes(city.toLowerCase())) {
        // Search for relevant transportation options
        if (newContext.lastTopic === "buses" || !newContext.lastTopic) {
          newContext.searchResults = busRoutes.filter(
            (bus) => bus.departureCity.includes(city) || bus.arrivalCity.includes(city),
          )
        } else if (newContext.lastTopic === "trains") {
          newContext.searchResults = trainRoutes.filter(
            (train) => train.departureCity.includes(city) || train.arrivalCity.includes(city),
          )
        }
        break
      }
    }

    return newContext
  }

  // Generate enhanced response based on user query and context
  const generateEnhancedResponse = (
    query: string,
    currentContext: ConversationContext,
  ): {
    response: string
    suggestedReplies?: string[]
    newContext: ConversationContext
  } => {
    const normalizedQuery = query.toLowerCase()
    const newContext = { ...currentContext }
    let suggestedReplies: string[] = []

    // Get user insights for more personalized responses
    const userInsights = aiService.getUserInsights()

    // Handle specific event information request
    if (currentContext.lastMentionedEvent) {
      const event = currentContext.lastMentionedEvent

      if (normalizedQuery.includes("when") || normalizedQuery.includes("date") || normalizedQuery.includes("time")) {
        return {
          response: `${event.name} is scheduled for ${event.date} at ${event.time}.`,
          suggestedReplies: ["Where is it located?", "How do I book tickets?", "What type of event is it?"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("where") ||
        normalizedQuery.includes("venue") ||
        normalizedQuery.includes("location")
      ) {
        return {
          response: `${event.name} will be held at ${event.venue}.`,
          suggestedReplies: ["When is it?", "How do I book tickets?", "What type of event is it?"],
          newContext,
        }
      }

      if (normalizedQuery.includes("type") || normalizedQuery.includes("kind") || normalizedQuery.includes("what is")) {
        return {
          response: `${event.name} is a ${event.type === "general" ? "general entertainment" : event.type} event.`,
          suggestedReplies: ["When is it?", "Where is it located?", "How do I book tickets?"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("book") ||
        normalizedQuery.includes("ticket") ||
        normalizedQuery.includes("reserve")
      ) {
        return {
          response: `To book tickets for ${event.name}, go to the Events page, select this event, and follow the seat selection process. You'll be able to choose your seats and complete the booking.`,
          suggestedReplies: [
            "Show me other events",
            "What transportation options are available?",
            "How much do tickets cost?",
          ],
          newContext,
        }
      }

      // Default response for an event
      return {
        response: `${event.name} is a ${event.type === "general" ? "general entertainment" : event.type} event scheduled for ${event.date} at ${event.time} in ${event.venue}. Would you like to know more or book tickets?`,
        suggestedReplies: ["Book tickets", "Show me other events", "What transportation options are available?"],
        newContext,
      }
    }

    // Handle specific bus information request
    if (currentContext.lastMentionedBus) {
      const bus = currentContext.lastMentionedBus

      if (
        normalizedQuery.includes("when") ||
        normalizedQuery.includes("time") ||
        normalizedQuery.includes("schedule")
      ) {
        return {
          response: `${bus.operator} bus ${bus.busNumber} departs from ${bus.departureCity} at ${bus.departureTime} and arrives in ${bus.arrivalCity} at ${bus.arrivalTime} on ${bus.departureDate}.`,
          suggestedReplies: [
            "How much does it cost?",
            "What amenities are available?",
            "How many seats are available?",
          ],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("price") ||
        normalizedQuery.includes("cost") ||
        normalizedQuery.includes("how much")
      ) {
        return {
          response: `The ticket for ${bus.operator} bus ${bus.busNumber} from ${bus.departureCity} to ${bus.arrivalCity} costs $${bus.price}.`,
          suggestedReplies: ["What amenities are included?", "When does it depart?", "How many seats are available?"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("amenities") ||
        normalizedQuery.includes("features") ||
        normalizedQuery.includes("services")
      ) {
        return {
          response: `${bus.operator} bus ${bus.busNumber} offers the following amenities: ${bus.amenities.join(", ")}.`,
          suggestedReplies: ["How much does it cost?", "When does it depart?", "How many seats are available?"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("seat") ||
        normalizedQuery.includes("available") ||
        normalizedQuery.includes("capacity")
      ) {
        const availabilityPercentage = Math.round((bus.availableSeats / bus.totalSeats) * 100)
        return {
          response: `${bus.operator} bus ${bus.busNumber} has ${bus.availableSeats} seats available out of ${bus.totalSeats} total seats (${availabilityPercentage}% available).`,
          suggestedReplies: ["How much does it cost?", "What amenities are included?", "When does it depart?"],
          newContext,
        }
      }

      // Default response for a bus
      return {
        response: `${bus.operator} bus ${bus.busNumber} travels from ${bus.departureCity} to ${bus.arrivalCity}, departing at ${bus.departureTime} on ${bus.departureDate}. The journey takes ${bus.duration} and costs $${bus.price}. This ${bus.busType} bus has ${bus.availableSeats} seats available and offers amenities like ${bus.amenities.slice(0, 3).join(", ")}${bus.amenities.length > 3 ? ", and more" : ""}.`,
        suggestedReplies: ["What amenities are included?", "How many seats are available?", "Show me other bus routes"],
        newContext,
      }
    }

    // Handle specific train information request
    if (currentContext.lastMentionedTrain) {
      const train = currentContext.lastMentionedTrain

      if (
        normalizedQuery.includes("when") ||
        normalizedQuery.includes("time") ||
        normalizedQuery.includes("schedule")
      ) {
        return {
          response: `${train.trainName} (${train.trainNumber}) departs from ${train.departureCity} at ${train.departureTime} and arrives in ${train.arrivalCity} at ${train.arrivalTime} on ${train.departureDate}.`,
          suggestedReplies: ["How much does it cost?", "What amenities are available?", "What stops does it make?"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("price") ||
        normalizedQuery.includes("cost") ||
        normalizedQuery.includes("how much")
      ) {
        return {
          response: `Tickets for ${train.trainName} (${train.trainNumber}) from ${train.departureCity} to ${train.arrivalCity} cost $${train.price.economy} for economy, $${train.price.business} for business class, and $${train.price.firstClass} for first class.`,
          suggestedReplies: ["What amenities are included?", "When does it depart?", "What stops does it make?"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("amenities") ||
        normalizedQuery.includes("features") ||
        normalizedQuery.includes("services")
      ) {
        return {
          response: `${train.trainName} (${train.trainNumber}) offers the following amenities: ${train.amenities.join(", ")}.`,
          suggestedReplies: ["How much does it cost?", "When does it depart?", "What stops does it make?"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("stop") ||
        normalizedQuery.includes("station") ||
        normalizedQuery.includes("route")
      ) {
        return {
          response:
            train.stops.length > 0
              ? `${train.trainName} (${train.trainNumber}) makes stops at: ${train.stops.join(", ")} between ${train.departureCity} and ${train.arrivalCity}.`
              : `${train.trainName} (${train.trainNumber}) is a direct service between ${train.departureCity} and ${train.arrivalCity} with no intermediate stops.`,
          suggestedReplies: ["How much does it cost?", "What amenities are included?", "When does it depart?"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("seat") ||
        normalizedQuery.includes("available") ||
        normalizedQuery.includes("capacity")
      ) {
        return {
          response: `${train.trainName} (${train.trainNumber}) has ${train.availableSeats.economy} economy seats, ${train.availableSeats.business} business class seats, and ${train.availableSeats.firstClass} first class seats available.`,
          suggestedReplies: ["How much does it cost?", "What amenities are included?", "When does it depart?"],
          newContext,
        }
      }

      // Default response for a train
      return {
        response: `${train.trainName} (${train.trainNumber}) is a ${train.trainType} train traveling from ${train.departureCity} to ${train.arrivalCity}, departing at ${train.departureTime} on ${train.departureDate} from platform ${train.platform}. The journey takes ${train.duration}. Economy tickets cost $${train.price.economy}, business class $${train.price.business}, and first class $${train.price.firstClass}. The train offers amenities like ${train.amenities.slice(0, 3).join(", ")}${train.amenities.length > 3 ? ", and more" : ""}.`,
        suggestedReplies: ["What stops does it make?", "How many seats are available?", "Show me other train routes"],
        newContext,
      }
    }

    // Handle search results
    if (currentContext.searchResults && currentContext.searchResults.length > 0) {
      const results = currentContext.searchResults

      if (results[0].hasOwnProperty("busNumber")) {
        // Bus results
        const busResults = results as BusRoute[]
        const resultsList = busResults
          .slice(0, 3)
          .map(
            (bus) =>
              `- ${bus.operator} (${bus.busNumber}): ${bus.departureCity} to ${bus.arrivalCity}, ${bus.departureTime}, $${bus.price}`,
          )
          .join("\n")

        suggestedReplies = busResults.slice(0, 3).map((bus) => `Tell me about ${bus.operator} ${bus.busNumber}`)

        return {
          response: `I found ${busResults.length} bus routes matching your criteria. Here are some options:\n${resultsList}\n\nWhich one would you like to know more about?`,
          suggestedReplies,
          newContext: {
            ...newContext,
            searchResults: undefined, // Clear search results after showing them
          },
        }
      } else if (results[0].hasOwnProperty("trainNumber")) {
        // Train results
        const trainResults = results as TrainRoute[]
        const resultsList = trainResults
          .slice(0, 3)
          .map(
            (train) =>
              `- ${train.trainName} (${train.trainNumber}): ${train.departureCity} to ${train.arrivalCity}, ${train.departureTime}, from $${train.price.economy}`,
          )
          .join("\n")

        suggestedReplies = trainResults.slice(0, 3).map((train) => `Tell me about ${train.trainName}`)

        return {
          response: `I found ${trainResults.length} train routes matching your criteria. Here are some options:\n${resultsList}\n\nWhich one would you like to know more about?`,
          suggestedReplies,
          newContext: {
            ...newContext,
            searchResults: undefined, // Clear search results after showing them
          },
        }
      } else {
        // Event results
        const eventResults = results as Event[]
        const resultsList = eventResults
          .slice(0, 3)
          .map((event) => `- ${event.name}: ${event.date}, ${event.time} at ${event.venue}`)
          .join("\n")

        suggestedReplies = eventResults.slice(0, 3).map((event) => `Tell me about ${event.name}`)

        return {
          response: `I found ${eventResults.length} events matching your criteria. Here are some options:\n${resultsList}\n\nWhich one would you like to know more about?`,
          suggestedReplies,
          newContext: {
            ...newContext,
            searchResults: undefined, // Clear search results after showing them
          },
        }
      }
    }

    // Handle general topic-based queries
    if (currentContext.lastTopic === "events") {
      if (normalizedQuery.includes("how many")) {
        return {
          response: `We have ${initialEvents.length} events available for booking.`,
          suggestedReplies: ["List all events", "Show me cinema events", "Show me concerts"],
          newContext,
        }
      }

      // When listing events, prioritize based on user preferences
      if (normalizedQuery.includes("list") || normalizedQuery.includes("what events")) {
        const recommendations = aiService.generateRecommendations(initialEvents, 5)

        const eventsList = recommendations
          .map(
            (event, index) =>
              `${index + 1}. ${event.name} on ${event.date} at ${event.time}, ${event.venue} (${Math.round((event as any).aiScore * 10)}% match)`,
          )
          .join("\n")

        suggestedReplies = recommendations.slice(0, 3).map((event) => `Tell me about ${event.name}`)
        suggestedReplies.push("Show more events")

        return {
          response: `Here are some personalized event recommendations for you:\n\n${eventsList}\n\nThese are selected based on your preferences and browsing history.`,
          suggestedReplies,
          newContext: { ...newContext, lastTopic: "events" },
        }
      }

      // Default response for events topic
      return {
        response:
          "We have various events including movies, concerts, and sports games. What type of event are you interested in?",
        suggestedReplies: ["Show me movies", "Show me concerts", "Show me sports events", "Show all events"],
        newContext,
      }
    }

    if (currentContext.lastTopic === "buses") {
      if (normalizedQuery.includes("how many")) {
        return {
          response: `We have ${busRoutes.length} bus routes available.`,
          suggestedReplies: ["List all bus routes", "Show luxury buses", "Show cheapest buses"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("list") ||
        normalizedQuery.includes("show me") ||
        normalizedQuery.includes("what bus")
      ) {
        let filteredBuses = busRoutes

        // Filter by price if specified
        if (currentContext.userPreferences?.priceRange) {
          const { min, max } = currentContext.userPreferences.priceRange
          filteredBuses = filteredBuses.filter((bus) => bus.price >= min && bus.price <= max)
        }

        // Filter by specific terms in the query
        if (normalizedQuery.includes("luxury") || normalizedQuery.includes("premium")) {
          filteredBuses = filteredBuses.filter(
            (bus) => bus.busType.toLowerCase() === "luxury" || bus.busType.toLowerCase() === "premium",
          )
        } else if (
          normalizedQuery.includes("cheap") ||
          normalizedQuery.includes("budget") ||
          normalizedQuery.includes("affordable")
        ) {
          filteredBuses = [...filteredBuses].sort((a, b) => a.price - b.price)
        } else if (
          normalizedQuery.includes("night") ||
          normalizedQuery.includes("evening") ||
          normalizedQuery.includes("overnight")
        ) {
          filteredBuses = filteredBuses.filter((bus) => {
            const hour = Number.parseInt(bus.departureTime.split(":")[0])
            const isPM = bus.departureTime.includes("PM")
            return (isPM && hour >= 6) || (bus.departureTime.includes("AM") && hour < 6)
          })
        }

        if (filteredBuses.length === 0) {
          return {
            response:
              "I couldn't find any bus routes matching your criteria. Would you like to see all available bus routes instead?",
            suggestedReplies: ["Show all bus routes", "Show luxury buses", "Show cheapest buses"],
            newContext,
          }
        }

        const busList = filteredBuses
          .slice(0, 5)
          .map(
            (bus, index) =>
              `${index + 1}. ${bus.operator} (${bus.busNumber}): ${bus.departureCity} to ${bus.arrivalCity}, ${bus.departureTime}, $${bus.price}`,
          )
          .join("\n")

        suggestedReplies = filteredBuses.slice(0, 3).map((bus) => `Tell me about ${bus.operator} ${bus.busNumber}`)
        suggestedReplies.push("Show more bus routes")

        return {
          response: `Here are ${filteredBuses.length > 5 ? "some" : "the"} ${filteredBuses.length > 5 ? `of the ${filteredBuses.length}` : ""} bus routes${currentContext.userPreferences?.priceRange ? ` within your price range` : ""}:\n\n${busList}${filteredBuses.length > 5 ? "\n\nWould you like to see more bus routes?" : ""}`,
          suggestedReplies,
          newContext,
        }
      }

      // Default response for buses topic
      return {
        response:
          "We offer various bus routes with different operators, amenities, and price points. What specific information are you looking for?",
        suggestedReplies: [
          "Show me all bus routes",
          "Show me luxury buses",
          "Show me the cheapest buses",
          "Show night buses",
        ],
        newContext,
      }
    }

    if (currentContext.lastTopic === "trains") {
      if (normalizedQuery.includes("how many")) {
        return {
          response: `We have ${trainRoutes.length} train routes available.`,
          suggestedReplies: ["List all train routes", "Show high-speed trains", "Show cheapest trains"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("list") ||
        normalizedQuery.includes("show me") ||
        normalizedQuery.includes("what train")
      ) {
        let filteredTrains = trainRoutes

        // Filter by price if specified
        if (currentContext.userPreferences?.priceRange) {
          const { min, max } = currentContext.userPreferences.priceRange
          filteredTrains = filteredTrains.filter((train) => train.price.economy >= min && train.price.economy <= max)
        }

        // Filter by specific terms in the query
        if (normalizedQuery.includes("high-speed") || normalizedQuery.includes("fast")) {
          filteredTrains = filteredTrains.filter((train) => train.trainType.toLowerCase().includes("high speed"))
        } else if (
          normalizedQuery.includes("cheap") ||
          normalizedQuery.includes("budget") ||
          normalizedQuery.includes("affordable")
        ) {
          filteredTrains = [...filteredTrains].sort((a, b) => a.price.economy - b.price.economy)
        } else if (
          normalizedQuery.includes("night") ||
          normalizedQuery.includes("evening") ||
          normalizedQuery.includes("overnight")
        ) {
          filteredTrains = filteredTrains.filter((train) => {
            const hour = Number.parseInt(train.departureTime.split(":")[0])
            const isPM = train.departureTime.includes("PM")
            return (isPM && hour >= 6) || (train.departureTime.includes("AM") && hour < 6)
          })
        }

        if (filteredTrains.length === 0) {
          return {
            response:
              "I couldn't find any train routes matching your criteria. Would you like to see all available train routes instead?",
            suggestedReplies: ["Show all train routes", "Show high-speed trains", "Show cheapest trains"],
            newContext,
          }
        }

        const trainList = filteredTrains
          .slice(0, 5)
          .map(
            (train, index) =>
              `${index + 1}. ${train.trainName} (${train.trainNumber}): ${train.departureCity} to ${train.arrivalCity}, ${train.departureTime}, from $${train.price.economy}`,
          )
          .join("\n")

        suggestedReplies = filteredTrains.slice(0, 3).map((train) => `Tell me about ${train.trainName}`)
        suggestedReplies.push("Show more train routes")

        return {
          response: `Here are ${filteredTrains.length > 5 ? "some" : "the"} ${filteredTrains.length > 5 ? `of the ${filteredTrains.length}` : ""} train routes${currentContext.userPreferences?.priceRange ? ` within your price range` : ""}:\n\n${trainList}${filteredTrains.length > 5 ? "\n\nWould you like to see more train routes?" : ""}`,
          suggestedReplies,
          newContext,
        }
      }

      // Default response for trains topic
      return {
        response:
          "We offer various train routes with different classes, amenities, and price points. What specific information are you looking for?",
        suggestedReplies: [
          "Show me all train routes",
          "Show me high-speed trains",
          "Show me the cheapest trains",
          "Show overnight trains",
        ],
        newContext,
      }
    }

    if (currentContext.lastTopic === "booking") {
      if (normalizedQuery.includes("how") || normalizedQuery.includes("process")) {
        return {
          response:
            "To book tickets, follow these steps:\n1. Select an event or transportation option from the main page\n2. Choose your preferred date and time\n3. Select your seats from the interactive seat map\n4. Review your booking details\n5. Complete the payment process\n6. Receive your e-ticket via email and in your 'My Bookings' section",
          suggestedReplies: [
            "Show me available events",
            "Show me transportation options",
            "Where can I find my bookings?",
          ],
          newContext,
        }
      }

      if (normalizedQuery.includes("cancel") || normalizedQuery.includes("refund")) {
        return {
          response:
            "To cancel a booking, go to the 'My Bookings' section, find the booking you wish to cancel, and click the 'Cancel Booking' button. Refund policies vary depending on how far in advance you cancel. Full refunds are typically available for cancellations made at least 48 hours before the event or departure.",
          suggestedReplies: ["Where can I find my bookings?", "What's the refund policy?", "Show me my bookings"],
          newContext,
        }
      }

      if (
        normalizedQuery.includes("find") ||
        normalizedQuery.includes("view") ||
        normalizedQuery.includes("my booking")
      ) {
        return {
          response:
            "You can find all your bookings in the 'My Bookings' section. This page shows both upcoming and past bookings, with options to view e-tickets, cancel bookings, or make changes where applicable.",
          suggestedReplies: ["How do I cancel a booking?", "Can I change my seats?", "Show me my bookings"],
          newContext,
        }
      }

      // Default response for booking topic
      return {
        response:
          "Our booking system allows you to easily reserve seats for events and transportation. You can select specific seats, manage your bookings, and access e-tickets all in one place. What specific information about the booking process would you like to know?",
        suggestedReplies: [
          "How do I book tickets?",
          "How do I cancel a booking?",
          "Where can I find my bookings?",
          "What's the refund policy?",
        ],
        newContext,
      }
    }

    // Handle general queries
    if (
      normalizedQuery.includes("event") ||
      normalizedQuery.includes("show") ||
      normalizedQuery.includes("movie") ||
      normalizedQuery.includes("concert") ||
      normalizedQuery.includes("game")
    ) {
      if (normalizedQuery.includes("how many")) {
        return {
          response: `We have ${initialEvents.length} events available for booking.`,
          suggestedReplies: ["List all events", "Show me cinema events", "Show me concerts"],
          newContext: { ...newContext, lastTopic: "events" },
        }
      }

      if (normalizedQuery.includes("list") || normalizedQuery.includes("what events")) {
        // Get user insights for more personalized responses
        const userInsights = aiService.getUserInsights()

        // When listing events, prioritize based on user preferences
        const recommendations = aiService.generateRecommendations(initialEvents, 5)

        const eventsList = recommendations
          .map(
            (event, index) =>
              `${index + 1}. ${event.name} on ${event.date} at ${event.time}, ${event.venue} (${Math.round((event as any).aiScore * 10)}% match)`,
          )
          .join("\n")

        suggestedReplies = recommendations.slice(0, 3).map((event) => `Tell me about ${event.name}`)
        suggestedReplies.push("Show more events")

        return {
          response: `Here are some personalized event recommendations for you:\n\n${eventsList}\n\nThese are selected based on your preferences and browsing history.`,
          suggestedReplies,
          newContext: { ...newContext, lastTopic: "events" },
        }
      }

      return {
        response:
          "We have various events including movies, concerts, and sports games. What type of event are you interested in?",
        suggestedReplies: ["Show me movies", "Show me concerts", "Show me sports events", "Show all events"],
        newContext: { ...newContext, lastTopic: "events" },
      }
    }

    if (normalizedQuery.includes("bus")) {
      if (normalizedQuery.includes("how many")) {
        return {
          response: `We have ${busRoutes.length} bus routes available.`,
          suggestedReplies: ["List all bus routes", "Show luxury buses", "Show cheapest buses"],
          newContext: { ...newContext, lastTopic: "buses" },
        }
      }

      if (normalizedQuery.includes("list") || normalizedQuery.includes("what bus")) {
        const busList = busRoutes
          .slice(0, 5)
          .map(
            (bus, index) =>
              `${index + 1}. ${bus.operator} (${bus.busNumber}): ${bus.departureCity} to ${bus.arrivalCity}, ${bus.departureTime}, $${bus.price}`,
          )
          .join("\n")

        suggestedReplies = busRoutes.slice(0, 3).map((bus) => `Tell me about ${bus.operator} ${bus.busNumber}`)
        suggestedReplies.push("Show more bus routes")

        return {
          response: `Here are some available bus routes:\n\n${busList}\n\nWould you like more information about a specific route?`,
          suggestedReplies,
          newContext: { ...newContext, lastTopic: "buses" },
        }
      }

      return {
        response:
          "We offer various bus routes with different operators, amenities, and price points. What specific information are you looking for?",
        suggestedReplies: [
          "Show me all bus routes",
          "Show me luxury buses",
          "Show me the cheapest buses",
          "Show night buses",
        ],
        newContext: { ...newContext, lastTopic: "buses" },
      }
    }

    if (normalizedQuery.includes("train")) {
      if (normalizedQuery.includes("how many")) {
        return {
          response: `We have ${trainRoutes.length} train routes available.`,
          suggestedReplies: ["List all train routes", "Show high-speed trains", "Show cheapest trains"],
          newContext: { ...newContext, lastTopic: "trains" },
        }
      }

      if (normalizedQuery.includes("list") || normalizedQuery.includes("what train")) {
        const trainList = trainRoutes
          .slice(0, 5)
          .map(
            (train, index) =>
              `${index + 1}. ${train.trainName} (${train.trainNumber}): ${train.departureCity} to ${train.arrivalCity}, ${train.departureTime}, from $${train.price.economy}`,
          )
          .join("\n")

        suggestedReplies = trainRoutes.slice(0, 3).map((train) => `Tell me about ${train.trainName}`)
        suggestedReplies.push("Show more train routes")

        return {
          response: `Here are some available train routes:\n\n${trainList}\n\nWould you like more information about a specific route?`,
          suggestedReplies,
          newContext: { ...newContext, lastTopic: "trains" },
        }
      }

      return {
        response:
          "We offer various train routes with different classes, amenities, and price points. What specific information are you looking for?",
        suggestedReplies: [
          "Show me all train routes",
          "Show me high-speed trains",
          "Show me the cheapest trains",
          "Show overnight trains",
        ],
        newContext: { ...newContext, lastTopic: "trains" },
      }
    }

    if (
      normalizedQuery.includes("book") ||
      normalizedQuery.includes("reservation") ||
      normalizedQuery.includes("ticket") ||
      normalizedQuery.includes("seat")
    ) {
      return {
        response:
          "To book tickets, select an event or transportation option from the main page, choose your preferred date and time, select your seats from the interactive seat map, and complete the payment process. You can view your bookings in the 'My Bookings' section after logging in.",
        suggestedReplies: [
          "Show me available events",
          "Show me transportation options",
          "How do I cancel a booking?",
          "Where can I find my bookings?",
        ],
        newContext: { ...newContext, lastTopic: "booking" },
      }
    }

    if (normalizedQuery.includes("price") || normalizedQuery.includes("cost") || normalizedQuery.includes("how much")) {
      if (normalizedQuery.includes("bus")) {
        const cheapestBus = busRoutes.reduce((prev, current) => (prev.price < current.price ? prev : current))
        const mostExpensiveBus = busRoutes.reduce((prev, current) => (prev.price > current.price ? prev : current))
        return {
          response: `Bus tickets range from $${cheapestBus.price} (${cheapestBus.operator} ${cheapestBus.busNumber}) to $${mostExpensiveBus.price} (${mostExpensiveBus.operator} ${mostExpensiveBus.busNumber}) depending on the route and amenities.`,
          suggestedReplies: ["Show me the cheapest buses", "Show me luxury buses", "What amenities are available?"],
          newContext: { ...newContext, lastTopic: "buses" },
        }
      }

      if (normalizedQuery.includes("train")) {
        const cheapestTrain = trainRoutes.reduce((prev, current) =>
          prev.price.economy < current.price.economy ? prev : current,
        )
        const mostExpensiveTrain = trainRoutes.reduce((prev, current) =>
          prev.price.firstClass > current.price.firstClass ? prev : current,
        )
        return {
          response: `Train tickets range from $${cheapestTrain.price.economy} for economy class (${cheapestTrain.trainName}) to $${mostExpensiveTrain.price.firstClass} for first class (${mostExpensiveTrain.trainName}), depending on the route and class of service.`,
          suggestedReplies: [
            "Show me the cheapest trains",
            "Show me high-speed trains",
            "What amenities are available?",
          ],
          newContext: { ...newContext, lastTopic: "trains" },
        }
      }

      return {
        response:
          "Prices vary depending on the event or transportation option. Could you specify what you're interested in? For events, prices depend on the venue and seating section. For transportation, prices vary based on route, class, and amenities.",
        suggestedReplies: [
          "How much do bus tickets cost?",
          "How much do train tickets cost?",
          "Show me the cheapest options",
        ],
        newContext,
      }
    }

    if (normalizedQuery.includes("transport") || normalizedQuery.includes("travel")) {
      return {
        response:
          "We offer both bus and train transportation options. Buses provide economical travel with various comfort levels from standard to luxury. Trains offer economy, business, and first-class options with different amenities. Which would you prefer to know more about?",
        suggestedReplies: [
          "Tell me about bus options",
          "Tell me about train options",
          "Show me the cheapest transport",
          "Show me the fastest transport",
        ],
        newContext,
      }
    }

    // Add personalized greeting based on user activity
    if (normalizedQuery.includes("hello") || normalizedQuery.includes("hi")) {
      const activityLevel = userInsights.activityLevel
      const favoriteType = userInsights.favoriteEventType

      let personalizedGreeting = "Hello! I'm your virtual assistant for this booking platform."

      if (activityLevel !== "low" && favoriteType !== "general") {
        personalizedGreeting += ` I see you're interested in ${favoriteType} events. `
      }

      personalizedGreeting +=
        " I can help you with information about events, transportation options, and booking procedures. How can I assist you today?"

      return {
        response: personalizedGreeting,
        suggestedReplies: [
          `Show me ${favoriteType} events`,
          "Tell me about transportation options",
          "How do I book tickets?",
        ],
        newContext,
      }
    }

    // Default responses for common queries
    if (normalizedQuery.includes("hello") || normalizedQuery.includes("hi")) {
      return {
        response:
          "Hello! I'm your virtual assistant for this booking platform. I can help you with information about events, transportation options, and booking procedures. How can I assist you today?",
        suggestedReplies: [
          "Show me available events",
          "Tell me about transportation options",
          "How do I book tickets?",
        ],
        newContext,
      }
    }

    if (normalizedQuery.includes("thank")) {
      return {
        response:
          "You're welcome! I'm happy to help. Is there anything else you'd like to know about our events, transportation options, or booking procedures?",
        suggestedReplies: [
          "Show me available events",
          "Tell me about transportation options",
          "How do I book tickets?",
        ],
        newContext,
      }
    }

    if (normalizedQuery.includes("help")) {
      return {
        response:
          "I can help you with:\n\n1. Finding events (movies, concerts, sports)\n2. Exploring transportation options (buses and trains)\n3. Understanding the booking process\n4. Answering questions about prices, schedules, and amenities\n\nWhat would you like to know about?",
        suggestedReplies: [
          "Show me available events",
          "Tell me about transportation options",
          "How do I book tickets?",
          "What are the prices?",
        ],
        newContext,
      }
    }

    if (
      normalizedQuery.includes("clear") ||
      normalizedQuery.includes("reset") ||
      normalizedQuery.includes("start over")
    ) {
      return {
        response: "I've reset our conversation. How can I help you today?",
        suggestedReplies: [
          "Show me available events",
          "Tell me about transportation options",
          "How do I book tickets?",
        ],
        newContext: {}, // Reset context
      }
    }

    // Fallback response
    return {
      response:
        "I can provide information about events, transportation options like buses and trains, or help with booking questions. What would you like to know about?",
      suggestedReplies: [
        "Show me available events",
        "Tell me about transportation options",
        "How do I book tickets?",
        "What are the prices?",
      ],
      newContext,
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleSuggestedReply = (reply: string) => {
    setInputValue(reply)
    setTimeout(() => handleSendMessage(), 100)
  }

  const handleClearChat = () => {
    setMessages([
      {
        id: "1",
        content:
          "👋 Hi there! I'm your virtual assistant. I can answer questions about events, transportation options, and bookings on this site. How can I help you today?",
        sender: "bot",
        timestamp: new Date(),
        suggestedReplies: [
          "What events are available?",
          "Tell me about transportation options",
          "How do I book tickets?",
        ],
      },
    ])
    setContext({})
    localStorage.removeItem("chatHistory")
  }

  return (
    <>
      {/* Floating button */}
      {!isOpen && (
        <motion.div
          className="fixed bottom-4 right-4 z-50"
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0, opacity: 0 }}
        >
          <Button
            onClick={() => setIsOpen(true)}
            className="h-14 w-14 rounded-full shadow-lg cursor-pointer"
            size="icon"
          >
            <MessageSquare className="h-6 w-6" />
          </Button>
        </motion.div>
      )}

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed bottom-4 right-4 z-50 w-80 md:w-96"
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
          >
            <Card className="shadow-xl border-2 border-primary/10 overflow-hidden">
              <CardHeader className="p-4 bg-primary/5">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg flex items-center">
                    <MessageSquare className="h-5 w-5 mr-2 text-primary" />
                    Virtual Assistant
                  </CardTitle>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 cursor-pointer"
                      onClick={handleClearChat}
                      title="Clear chat history"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M3 6h18"></path>
                        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                        <line x1="10" y1="11" x2="10" y2="17"></line>
                        <line x1="14" y1="11" x2="14" y2="17"></line>
                      </svg>
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 cursor-pointer"
                      onClick={() => setIsMinimized(!isMinimized)}
                    >
                      {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 cursor-pointer"
                      onClick={() => setIsOpen(false)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <AnimatePresence>
                {!isMinimized && (
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: "auto" }}
                    exit={{ height: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <CardContent className="p-0">
                      <ScrollArea className="h-80 p-4">
                        <div className="flex flex-col gap-3">
                          {messages.map((message) => (
                            <div key={message.id} className="flex flex-col gap-2">
                              <div className={cn("flex gap-2 max-w-[90%]", message.sender === "user" ? "ml-auto" : "")}>
                                {message.sender === "bot" && (
                                  <Avatar className="h-8 w-8 bg-primary/20">
                                    <MessageSquare className="h-4 w-4 text-primary" />
                                  </Avatar>
                                )}
                                <div
                                  className={cn(
                                    "rounded-lg p-3 text-sm",
                                    message.sender === "user" ? "bg-primary text-primary-foreground" : "bg-muted",
                                  )}
                                >
                                  <div className="whitespace-pre-line">{message.content}</div>
                                  <div className="text-xs opacity-70 mt-1">
                                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                                  </div>
                                </div>
                              </div>

                              {/* Suggested replies */}
                              {message.sender === "bot" &&
                                message.suggestedReplies &&
                                message.suggestedReplies.length > 0 && (
                                  <div className="flex flex-wrap gap-2 ml-10 mt-1">
                                    {message.suggestedReplies.map((reply, index) => (
                                      <Badge
                                        key={index}
                                        variant="outline"
                                        className="cursor-pointer hover:bg-primary/10 transition-colors py-1 px-2"
                                        onClick={() => handleSuggestedReply(reply)}
                                      >
                                        {reply}
                                      </Badge>
                                    ))}
                                  </div>
                                )}
                            </div>
                          ))}
                          {isTyping && (
                            <div className="flex gap-2 max-w-[90%]">
                              <Avatar className="h-8 w-8 bg-primary/20">
                                <MessageSquare className="h-4 w-4 text-primary" />
                              </Avatar>
                              <div className="rounded-lg p-3 text-sm bg-muted">
                                <div className="flex gap-1">
                                  <span className="animate-bounce">•</span>
                                  <span className="animate-bounce" style={{ animationDelay: "0.2s" }}>
                                    •
                                  </span>
                                  <span className="animate-bounce" style={{ animationDelay: "0.4s" }}>
                                    •
                                  </span>
                                </div>
                              </div>
                            </div>
                          )}
                          <div ref={messagesEndRef} />
                        </div>
                      </ScrollArea>
                    </CardContent>

                    <CardFooter className="p-3 border-t">
                      <div className="flex w-full gap-2">
                        <Textarea
                          value={inputValue}
                          onChange={(e) => setInputValue(e.target.value)}
                          onKeyDown={handleKeyDown}
                          placeholder="Type your message..."
                          className="min-h-[40px] resize-none"
                          rows={1}
                        />
                        <Button
                          onClick={handleSendMessage}
                          size="icon"
                          disabled={!inputValue.trim() || isTyping}
                          className="h-10 w-10 shrink-0 cursor-pointer"
                        >
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardFooter>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
