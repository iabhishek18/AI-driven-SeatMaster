"use client"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Sparkles, TrendingUp, Clock, Star } from "lucide-react"
import { motion } from "framer-motion"
import { aiService } from "@/lib/ai-service"
import { initialEvents } from "@/data/initial-data"
import type { Event } from "@/types/booking"

interface AIRecommendationsProps {
  onSelectEvent?: (event: Event) => void
  className?: string
}

export default function AIRecommendations({ onSelectEvent, className }: AIRecommendationsProps) {
  const [recommendations, setRecommendations] = useState<Event[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [userInsights, setUserInsights] = useState<any>(null)

  useEffect(() => {
    // Simulate AI processing time
    const timer = setTimeout(() => {
      const recs = aiService.generateRecommendations(initialEvents, 4)
      const insights = aiService.getUserInsights()

      setRecommendations(recs)
      setUserInsights(insights)
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleEventClick = (event: Event) => {
    aiService.trackUserBehavior("view_recommended_event", {
      eventId: event.id,
      type: event.type,
      venue: event.venue,
    })

    if (onSelectEvent) {
      onSelectEvent(event)
    }
  }

  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Sparkles className="h-5 w-5 mr-2 text-primary animate-pulse" />
            AI Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Sparkles className="h-5 w-5 mr-2 text-primary" />
            AI Recommendations
          </div>
          {userInsights && (
            <Badge variant="outline" className="text-xs">
              <TrendingUp className="h-3 w-3 mr-1" />
              {userInsights.activityLevel} activity
            </Badge>
          )}
        </CardTitle>
        {userInsights && (
          <p className="text-sm text-muted-foreground">
            Based on your interest in {userInsights.favoriteEventType} events
          </p>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {recommendations.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="border rounded-lg p-3 hover:bg-accent/50 transition-colors cursor-pointer"
              onClick={() => handleEventClick(event)}
            >
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-medium text-sm line-clamp-1">{event.name}</h4>
                <Badge variant="secondary" className="text-xs ml-2">
                  {Math.round((event as any).aiScore * 10)}% match
                </Badge>
              </div>

              <div className="flex items-center text-xs text-muted-foreground mb-2">
                <Clock className="h-3 w-3 mr-1" />
                {event.date} • {event.time}
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{event.venue}</span>
                <div className="flex items-center">
                  <Star className="h-3 w-3 text-yellow-400 fill-yellow-400 mr-1" />
                  <span className="text-xs">4.8</span>
                </div>
              </div>

              <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                {aiService.generateEventDescription(event)}
              </p>
            </motion.div>
          ))}
        </div>

        {recommendations.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Start browsing events to get personalized recommendations!</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
