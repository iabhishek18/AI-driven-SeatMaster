"use client"

import { Chatbot } from "./chatbot"

export function ChatbotProvider() {
  return <Chatbot />
}
