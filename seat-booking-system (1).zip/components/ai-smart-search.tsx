"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, Sparkles, Clock } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { aiService } from "@/lib/ai-service"
import { initialEvents } from "@/data/initial-data"
import { cn } from "@/lib/utils"

interface AISmartSearchProps {
  onSearch?: (query: string, results: any[]) => void
  placeholder?: string
  className?: string
}

export default function AISmartSearch({
  onSearch,
  placeholder = "Search events, venues, or experiences...",
  className,
}: AISmartSearchProps) {
  const [query, setQuery] = useState("")
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [isSearching, setIsSearching] = useState(false)
  const [recentSearches, setRecentSearches] = useState<string[]>([])
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    // Load recent searches from localStorage
    const recent = localStorage.getItem("recent_searches")
    if (recent) {
      setRecentSearches(JSON.parse(recent))
    }
  }, [])

  useEffect(() => {
    if (query.length > 1) {
      const newSuggestions = aiService.generateSearchSuggestions(query, initialEvents)
      setSuggestions(newSuggestions)
      setIsOpen(true)
    } else {
      setSuggestions([])
      setIsOpen(false)
    }
  }, [query])

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return

    setIsSearching(true)

    // Track search behavior
    aiService.trackUserBehavior("search", { query: searchQuery })

    // Add to recent searches
    const updatedRecent = [searchQuery, ...recentSearches.filter((s) => s !== searchQuery)].slice(0, 5)
    setRecentSearches(updatedRecent)
    localStorage.setItem("recent_searches", JSON.stringify(updatedRecent))

    // Simulate AI-powered search
    setTimeout(() => {
      const results = initialEvents.filter(
        (event) =>
          event.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          event.venue.toLowerCase().includes(searchQuery.toLowerCase()) ||
          event.type.toLowerCase().includes(searchQuery.toLowerCase()),
      )

      // Enhance results with AI scoring
      const enhancedResults = results
        .map((event) => ({
          ...event,
          relevanceScore: calculateRelevanceScore(event, searchQuery),
          aiDescription: aiService.generateEventDescription(event),
        }))
        .sort((a, b) => b.relevanceScore - a.relevanceScore)

      setIsSearching(false)
      setIsOpen(false)
      setQuery("")

      if (onSearch) {
        onSearch(searchQuery, enhancedResults)
      }
    }, 800)
  }

  const calculateRelevanceScore = (event: any, query: string): number => {
    const lowerQuery = query.toLowerCase()
    let score = 0

    // Exact name match gets highest score
    if (event.name.toLowerCase().includes(lowerQuery)) score += 10

    // Venue match
    if (event.venue.toLowerCase().includes(lowerQuery)) score += 7

    // Type match
    if (event.type.toLowerCase().includes(lowerQuery)) score += 5

    // Add user preference boost
    const userInsights = aiService.getUserInsights()
    if (userInsights.favoriteEventType === event.type) score += 3

    return score
  }

  const handleSuggestionClick = (suggestion: string) => {
    setQuery(suggestion)
    handleSearch(suggestion)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch(query)
    } else if (e.key === "Escape") {
      setIsOpen(false)
    }
  }

  return (
    <div className={cn("relative", className)}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          ref={inputRef}
          type="text"
          placeholder={placeholder}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsOpen(true)}
          className="pl-10 pr-12"
        />
        {isSearching ? (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <Sparkles className="h-4 w-4 text-primary animate-pulse" />
          </div>
        ) : (
          <Button
            size="sm"
            className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 px-3 cursor-pointer"
            onClick={() => handleSearch(query)}
          >
            <Search className="h-3 w-3" />
          </Button>
        )}
      </div>

      <AnimatePresence>
        {isOpen && (suggestions.length > 0 || recentSearches.length > 0) && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full left-0 right-0 mt-1 bg-background border rounded-md shadow-lg z-50 max-h-80 overflow-y-auto"
          >
            {suggestions.length > 0 && (
              <div className="p-2">
                <div className="flex items-center text-xs text-muted-foreground mb-2">
                  <Sparkles className="h-3 w-3 mr-1" />
                  AI Suggestions
                </div>
                {suggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    className="w-full text-left px-3 py-2 hover:bg-accent rounded-sm text-sm cursor-pointer"
                    onClick={() => handleSuggestionClick(suggestion)}
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            )}

            {recentSearches.length > 0 && (
              <div className="p-2 border-t">
                <div className="flex items-center text-xs text-muted-foreground mb-2">
                  <Clock className="h-3 w-3 mr-1" />
                  Recent Searches
                </div>
                <div className="flex flex-wrap gap-1">
                  {recentSearches.map((search, index) => (
                    <Badge
                      key={index}
                      variant="outline"
                      className="cursor-pointer hover:bg-accent text-xs"
                      onClick={() => handleSuggestionClick(search)}
                    >
                      {search}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
