"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Loader2, ZoomIn, ZoomOut, RotateCcw, Fullscreen, ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

interface PanoramaViewerProps {
  images: string[]
  className?: string
}

export default function PanoramaViewer({ images, className }: PanoramaViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [yaw, setYaw] = useState(0)
  const [pitch, setPitch] = useState(0)
  const [zoom, setZoom] = useState(75)
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [isFullscreen, setIsFullscreen] = useState(false)

  // Initialize the panorama viewer
  useEffect(() => {
    if (images.length === 0) return
    setIsLoading(true)

    const img = new Image()
    img.src = images[currentImageIndex]
    img.onload = () => {
      setIsLoading(false)
    }
    img.onerror = () => {
      setIsLoading(false)
    }

    return () => {
      img.onload = null
      img.onerror = null
    }
  }, [images, currentImageIndex])

  // Handle mouse events for dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX, y: e.clientY })
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return

    const sensitivity = 0.3
    const deltaX = (e.clientX - dragStart.x) * sensitivity
    const deltaY = (e.clientY - dragStart.y) * sensitivity

    setYaw((prev) => (prev - deltaX) % 360)
    setPitch((prev) => {
      const newPitch = prev + deltaY
      return Math.max(-90, Math.min(90, newPitch))
    })

    setDragStart({ x: e.clientX, y: e.clientY })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  // Handle touch events for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true)
      setDragStart({ x: e.touches[0].clientX, y: e.touches[0].clientY })
    }
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return

    const sensitivity = 0.3
    const deltaX = (e.touches[0].clientX - dragStart.x) * sensitivity
    const deltaY = (e.touches[0].clientY - dragStart.y) * sensitivity

    setYaw((prev) => (prev - deltaX) % 360)
    setPitch((prev) => {
      const newPitch = prev + deltaY
      return Math.max(-90, Math.min(90, newPitch))
    })

    setDragStart({ x: e.touches[0].clientX, y: e.touches[0].clientY })
  }

  const handleTouchEnd = () => {
    setIsDragging(false)
  }

  // Handle zoom controls
  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 10, 110))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 10, 50))
  }

  // Handle reset view
  const handleReset = () => {
    setYaw(0)
    setPitch(0)
    setZoom(75)
  }

  // Handle fullscreen toggle
  const toggleFullscreen = () => {
    if (!containerRef.current) return

    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen()
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      }
    }
  }

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  // Navigate between panorama images
  const goToNextImage = () => {
    if (images.length <= 1) return
    setCurrentImageIndex((prev) => (prev + 1) % images.length)
    handleReset()
  }

  const goToPrevImage = () => {
    if (images.length <= 1) return
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length)
    handleReset()
  }

  // Calculate transform style based on yaw, pitch, and zoom
  const transformStyle = {
    transform: `perspective(1000px) rotateX(${pitch}deg) rotateY(${yaw}deg) scale3d(${zoom / 100}, ${zoom / 100}, ${
      zoom / 100
    })`,
  }

  return (
    <div
      ref={containerRef}
      className={cn(
        "relative w-full h-[400px] overflow-hidden rounded-md bg-black/10 select-none",
        isFullscreen ? "fixed inset-0 z-50 h-screen w-screen rounded-none" : "",
        className,
      )}
    >
      {/* Loading indicator */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-20">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
        </div>
      )}

      {/* Panorama container */}
      <div
        className="w-full h-full cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
          <div className="w-[200%] h-[200%] transition-transform duration-75 ease-linear" style={transformStyle}>
            <img
              src={images[currentImageIndex] || "/placeholder.svg"}
              alt="360° panorama view"
              className="w-full h-full object-cover"
              draggable={false}
              onError={(e) => {
                e.currentTarget.src = `/placeholder.svg?height=2000&width=4000&query=360%20panorama%20venue`
              }}
            />
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 z-10">
        <Button
          variant="secondary"
          size="icon"
          className="h-9 w-9 rounded-full bg-white/80 hover:bg-white/90 text-black cursor-pointer"
          onClick={handleZoomOut}
          aria-label="Zoom out"
        >
          <ZoomOut className="h-5 w-5" />
        </Button>
        <Button
          variant="secondary"
          size="icon"
          className="h-9 w-9 rounded-full bg-white/80 hover:bg-white/90 text-black cursor-pointer"
          onClick={handleReset}
          aria-label="Reset view"
        >
          <RotateCcw className="h-5 w-5" />
        </Button>
        <Button
          variant="secondary"
          size="icon"
          className="h-9 w-9 rounded-full bg-white/80 hover:bg-white/90 text-black cursor-pointer"
          onClick={handleZoomIn}
          aria-label="Zoom in"
        >
          <ZoomIn className="h-5 w-5" />
        </Button>
        <Button
          variant="secondary"
          size="icon"
          className="h-9 w-9 rounded-full bg-white/80 hover:bg-white/90 text-black cursor-pointer"
          onClick={toggleFullscreen}
          aria-label="Toggle fullscreen"
        >
          <Fullscreen className="h-5 w-5" />
        </Button>
      </div>

      {/* Navigation between panoramas */}
      {images.length > 1 && (
        <>
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-4 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/80 hover:bg-white/90 text-black cursor-pointer z-10"
            onClick={goToPrevImage}
            aria-label="Previous panorama"
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-white/80 hover:bg-white/90 text-black cursor-pointer z-10"
            onClick={goToNextImage}
            aria-label="Next panorama"
          >
            <ChevronRight className="h-6 w-6" />
          </Button>
          <div className="absolute top-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm z-10">
            {currentImageIndex + 1} / {images.length}
          </div>
        </>
      )}

      {/* Instructions overlay */}
      <div className="absolute top-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-xs z-10">
        Drag to look around
      </div>
    </div>
  )
}
