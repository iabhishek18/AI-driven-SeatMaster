"use client"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Brain, TrendingUp, Calendar, MapPin, BarChart3, Sparkles, RefreshCw, Settings } from "lucide-react"
import { motion } from "framer-motion"
import { aiService } from "@/lib/ai-service"

interface AIInsightsDashboardProps {
  className?: string
}

export default function AIInsightsDashboard({ className }: AIInsightsDashboardProps) {
  const [insights, setInsights] = useState<any>(null)
  const [notifications, setNotifications] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const loadInsights = () => {
    setIsLoading(true)
    setTimeout(() => {
      const userInsights = aiService.getUserInsights()
      const smartNotifications = aiService.generateSmartNotifications()

      setInsights(userInsights)
      setNotifications(smartNotifications)
      setIsLoading(false)
    }, 500)
  }

  useEffect(() => {
    loadInsights()
  }, [])

  const getActivityColor = (level: string) => {
    switch (level) {
      case "high":
        return "text-green-600"
      case "medium":
        return "text-yellow-600"
      case "low":
        return "text-red-600"
      default:
        return "text-gray-600"
    }
  }

  const getActivityProgress = (level: string) => {
    switch (level) {
      case "high":
        return 85
      case "medium":
        return 50
      case "low":
        return 20
      default:
        return 0
    }
  }

  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Brain className="h-5 w-5 mr-2 text-primary animate-pulse" />
            AI Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className={className}>
      <Card className="mb-4">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <Brain className="h-5 w-5 mr-2 text-primary" />
              AI Insights
            </div>
            <Button variant="outline" size="sm" onClick={loadInsights} className="cursor-pointer">
              <RefreshCw className="h-4 w-4 mr-1" />
              Refresh
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {insights && (
            <div className="space-y-4">
              {/* Activity Level */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Activity Level</span>
                  <Badge variant="outline" className={getActivityColor(insights.activityLevel)}>
                    {insights.activityLevel}
                  </Badge>
                </div>
                <Progress value={getActivityProgress(insights.activityLevel)} className="h-2" />
                <p className="text-xs text-muted-foreground">
                  {insights.totalInteractions} total interactions recorded
                </p>
              </div>

              {/* Preferences */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-primary" />
                    <span className="text-sm font-medium">Favorite Event Type</span>
                  </div>
                  <Badge variant="secondary">{insights.favoriteEventType}</Badge>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2 text-primary" />
                    <span className="text-sm font-medium">Favorite Venue</span>
                  </div>
                  <Badge variant="secondary">{insights.favoriteVenue}</Badge>
                </div>
              </div>

              {/* Event Type Preferences */}
              {Object.keys(insights.preferences.eventTypes).length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center">
                    <BarChart3 className="h-4 w-4 mr-2 text-primary" />
                    <span className="text-sm font-medium">Event Type Preferences</span>
                  </div>
                  <div className="space-y-1">
                    {Object.entries(insights.preferences.eventTypes)
                      .sort(([, a], [, b]) => (b as number) - (a as number))
                      .slice(0, 3)
                      .map(([type, count]) => (
                        <div key={type} className="flex items-center justify-between">
                          <span className="text-xs capitalize">{type}</span>
                          <div className="flex items-center">
                            <div className="w-16 h-1 bg-gray-200 rounded mr-2">
                              <div
                                className="h-full bg-primary rounded"
                                style={{
                                  width: `${Math.min(100, ((count as number) / Math.max(...Object.values(insights.preferences.eventTypes))) * 100)}%`,
                                }}
                              />
                            </div>
                            <span className="text-xs text-muted-foreground">{count}</span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Smart Notifications */}
      {notifications.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Sparkles className="h-5 w-5 mr-2 text-primary" />
              Smart Notifications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {notifications.map((notification, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border rounded-lg p-3 bg-accent/20"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center mb-1">
                        <Badge
                          variant={notification.type === "recommendation" ? "default" : "secondary"}
                          className="text-xs mr-2"
                        >
                          {notification.type}
                        </Badge>
                        <div className="flex">
                          {Array.from({ length: notification.priority }).map((_, i) => (
                            <TrendingUp key={i} className="h-3 w-3 text-primary" />
                          ))}
                        </div>
                      </div>
                      <p className="text-sm">{notification.message}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Privacy Controls */}
      <Card className="mt-4">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Settings className="h-5 w-5 mr-2 text-primary" />
            AI Privacy Controls
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Your data is used to provide personalized recommendations and improve your experience.
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                aiService.clearUserData()
                loadInsights()
              }}
              className="cursor-pointer"
            >
              Clear All Data
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
