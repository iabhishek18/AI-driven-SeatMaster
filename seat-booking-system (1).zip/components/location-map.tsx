"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MapPin, Navigation, Search, ZoomIn, ZoomOut, Locate, Star } from "lucide-react"
import { geolocationService, type LocationData, type NearbyLocation } from "@/lib/geolocation-service"
import { initialEvents } from "@/data/initial-data"

interface LocationMapProps {
  onLocationSelect?: (location: NearbyLocation) => void
  showSearch?: boolean
  showFilters?: boolean
  className?: string
}

export default function LocationMap({
  onLocationSelect,
  showSearch = true,
  showFilters = true,
  className = "",
}: LocationMapProps) {
  const [userLocation, setUserLocation] = useState<LocationData | null>(null)
  const [nearbyLocations, setNearbyLocations] = useState<NearbyLocation[]>([])
  const [selectedLocation, setSelectedLocation] = useState<NearbyLocation | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState<string>("all")
  const [radiusKm, setRadiusKm] = useState(10)
  const [isLoading, setIsLoading] = useState(false)
  const mapRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Subscribe to location updates
    const unsubscribe = geolocationService.onLocationChange((location) => {
      setUserLocation(location)
      if (location) {
        findNearbyLocations(location)
      }
    })

    // Check for cached location
    const cachedLocation = geolocationService.getCachedLocation()
    if (cachedLocation) {
      setUserLocation(cachedLocation)
      findNearbyLocations(cachedLocation)
    }

    return unsubscribe
  }, [radiusKm])

  const findNearbyLocations = (location: LocationData) => {
    const nearby = geolocationService.findNearbyLocations(
      location.latitude,
      location.longitude,
      initialEvents,
      radiusKm,
    )
    setNearbyLocations(nearby)
  }

  const getCurrentLocation = async () => {
    setIsLoading(true)
    try {
      const location = await geolocationService.getCurrentLocation()
      setUserLocation(location)
      findNearbyLocations(location)
    } catch (error) {
      console.error("Failed to get location:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleLocationClick = (location: NearbyLocation) => {
    setSelectedLocation(location)
    if (onLocationSelect) {
      onLocationSelect(location)
    }
  }

  const filteredLocations = nearbyLocations.filter((location) => {
    const matchesSearch =
      location.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      location.address.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = filterType === "all" || location.type === filterType
    return matchesSearch && matchesType
  })

  const getLocationIcon = (type: string) => {
    switch (type) {
      case "venue":
        return "🏟️"
      case "event":
        return "🎭"
      case "transport":
        return "🚌"
      default:
        return "📍"
    }
  }

  const getDistanceColor = (distance: number) => {
    if (distance < 2) return "text-green-600"
    if (distance < 5) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Button onClick={getCurrentLocation} disabled={isLoading} variant="outline" className="flex-shrink-0">
          <Locate className="mr-2 h-4 w-4" />
          {isLoading ? "Getting Location..." : "Get My Location"}
        </Button>

        {showSearch && (
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search locations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        )}

        {showFilters && (
          <div className="flex gap-2">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="venue">Venues</SelectItem>
                <SelectItem value="event">Events</SelectItem>
                <SelectItem value="transport">Transport</SelectItem>
              </SelectContent>
            </Select>

            <Select value={radiusKm.toString()} onValueChange={(value) => setRadiusKm(Number(value))}>
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5 km</SelectItem>
                <SelectItem value="10">10 km</SelectItem>
                <SelectItem value="25">25 km</SelectItem>
                <SelectItem value="50">50 km</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      {/* Map Container */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Visual Map */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Interactive Map
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div
              ref={mapRef}
              className="relative w-full h-80 bg-gradient-to-br from-slate-50 to-blue-50 rounded-lg border overflow-hidden"
            >
              {/* Real Interactive Map using OpenStreetMap */}
              <div className="relative w-full h-full">
                <iframe
                  src={`https://www.openstreetmap.org/export/embed.html?bbox=${
                    userLocation
                      ? `${userLocation.longitude - 0.01},${userLocation.latitude - 0.01},${userLocation.longitude + 0.01},${userLocation.latitude + 0.01}`
                      : "-74.1,40.6,-73.9,40.8"
                  }&layer=mapnik&marker=${
                    userLocation ? `${userLocation.latitude},${userLocation.longitude}` : "40.7128,-74.0060"
                  }`}
                  className="w-full h-full rounded-lg border-0"
                  style={{ minHeight: "320px" }}
                  loading="lazy"
                  title="Interactive Map"
                />

                {/* Overlay for custom markers */}
                <div className="absolute inset-0 pointer-events-none">
                  {/* User Location Marker */}
                  {userLocation && (
                    <div
                      className="absolute w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse pointer-events-auto z-10"
                      style={{
                        left: "50%",
                        top: "50%",
                        transform: "translate(-50%, -50%)",
                      }}
                      title="Your Location"
                    >
                      <div className="absolute inset-0 bg-blue-400 rounded-full animate-ping opacity-75"></div>
                    </div>
                  )}

                  {/* Nearby Location Markers */}
                  {filteredLocations.map((location, index) => {
                    // Calculate relative position based on distance and bearing
                    const bearing = (index / filteredLocations.length) * 360
                    const distance = Math.min(location.distance * 8, 100) // Scale for visual representation
                    const radians = (bearing * Math.PI) / 180
                    const x = 50 + (distance * Math.sin(radians)) / 4
                    const y = 50 - (distance * Math.cos(radians)) / 4

                    return (
                      <div
                        key={location.id}
                        className={`absolute w-6 h-6 rounded-full border-2 border-white shadow-lg cursor-pointer transition-all hover:scale-125 pointer-events-auto z-10 ${
                          selectedLocation?.id === location.id
                            ? "bg-red-500 scale-125"
                            : "bg-orange-500 hover:bg-red-400"
                        }`}
                        style={{
                          left: `${Math.max(5, Math.min(95, x))}%`,
                          top: `${Math.max(5, Math.min(95, y))}%`,
                          transform: "translate(-50%, -50%)",
                        }}
                        onClick={() => handleLocationClick(location)}
                        title={`${location.name} (${location.distance}km)`}
                      >
                        <span className="absolute inset-0 flex items-center justify-center text-xs">
                          {getLocationIcon(location.type)}
                        </span>
                        <div className="absolute inset-0 bg-current rounded-full animate-ping opacity-30"></div>
                      </div>
                    )
                  })}
                </div>

                {/* Map Controls Overlay */}
                <div className="absolute top-2 right-2 flex flex-col gap-1 z-20">
                  <Button
                    size="sm"
                    variant="secondary"
                    className="w-8 h-8 p-0 bg-white/90 hover:bg-white"
                    onClick={() => {
                      if (userLocation) {
                        // Refresh the map to center on user location
                        const iframe = document.querySelector('iframe[title="Interactive Map"]') as HTMLIFrameElement
                        if (iframe) {
                          iframe.src = `https://www.openstreetmap.org/export/embed.html?bbox=${
                            userLocation.longitude - 0.01
                          },${userLocation.latitude - 0.01},${
                            userLocation.longitude + 0.01
                          },${userLocation.latitude + 0.01}&layer=mapnik&marker=${userLocation.latitude},${userLocation.longitude}`
                        }
                      }
                    }}
                    title="Center on my location"
                  >
                    <Locate className="h-3 w-3" />
                  </Button>

                  <Button
                    size="sm"
                    variant="secondary"
                    className="w-8 h-8 p-0 bg-white/90 hover:bg-white"
                    onClick={() => {
                      const iframe = document.querySelector('iframe[title="Interactive Map"]') as HTMLIFrameElement
                      if (iframe && userLocation) {
                        // Zoom in
                        iframe.src = `https://www.openstreetmap.org/export/embed.html?bbox=${
                          userLocation.longitude - 0.005
                        },${userLocation.latitude - 0.005},${
                          userLocation.longitude + 0.005
                        },${userLocation.latitude + 0.005}&layer=mapnik&marker=${userLocation.latitude},${userLocation.longitude}`
                      }
                    }}
                    title="Zoom in"
                  >
                    <ZoomIn className="h-3 w-3" />
                  </Button>

                  <Button
                    size="sm"
                    variant="secondary"
                    className="w-8 h-8 p-0 bg-white/90 hover:bg-white"
                    onClick={() => {
                      const iframe = document.querySelector('iframe[title="Interactive Map"]') as HTMLIFrameElement
                      if (iframe && userLocation) {
                        // Zoom out
                        iframe.src = `https://www.openstreetmap.org/export/embed.html?bbox=${
                          userLocation.longitude - 0.02
                        },${userLocation.latitude - 0.02},${
                          userLocation.longitude + 0.02
                        },${userLocation.latitude + 0.02}&layer=mapnik&marker=${userLocation.latitude},${userLocation.longitude}`
                      }
                    }}
                    title="Zoom out"
                  >
                    <ZoomOut className="h-3 w-3" />
                  </Button>
                </div>

                {/* Loading indicator */}
                {!userLocation && (
                  <div className="absolute inset-0 flex items-center justify-center bg-white/80 rounded-lg">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                      <p className="text-sm text-muted-foreground">Loading map...</p>
                    </div>
                  </div>
                )}
              </div>

              {userLocation && (
                <div className="mt-3 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-3 w-3" />
                    <span>{userLocation.address || "Current Location"}</span>
                  </div>
                  <div className="text-xs mt-1">Accuracy: ±{Math.round(userLocation.accuracy)}m</div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Location List */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Nearby Locations ({filteredLocations.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 max-h-80 overflow-y-auto">
            {filteredLocations.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {userLocation ? "No locations found in this area" : "Enable location to see nearby places"}
              </div>
            ) : (
              filteredLocations.map((location) => (
                <div
                  key={location.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                    selectedLocation?.id === location.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50"
                  }`}
                  onClick={() => handleLocationClick(location)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="text-lg">{getLocationIcon(location.type)}</span>
                        <h3 className="font-medium text-sm">{location.name}</h3>
                        <Badge variant="secondary" className="text-xs">
                          {location.type}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mb-2">{location.address}</p>
                      {location.description && (
                        <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{location.description}</p>
                      )}
                      <div className="flex items-center space-x-3 text-xs">
                        <div className={`flex items-center space-x-1 ${getDistanceColor(location.distance)}`}>
                          <Navigation className="h-3 w-3" />
                          <span>{location.distance}km away</span>
                        </div>
                        {location.rating && (
                          <div className="flex items-center space-x-1 text-yellow-600">
                            <Star className="h-3 w-3 fill-current" />
                            <span>{location.rating}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Selected Location Details */}
      {selectedLocation && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span className="text-xl">{getLocationIcon(selectedLocation.type)}</span>
              <span>{selectedLocation.name}</span>
              <Badge>{selectedLocation.type}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{selectedLocation.address}</span>
                </div>
                <div className={`flex items-center space-x-2 text-sm ${getDistanceColor(selectedLocation.distance)}`}>
                  <Navigation className="h-4 w-4" />
                  <span>{selectedLocation.distance}km away</span>
                </div>
                {selectedLocation.rating && (
                  <div className="flex items-center space-x-2 text-sm">
                    <Star className="h-4 w-4 text-yellow-500 fill-current" />
                    <span>{selectedLocation.rating}/5</span>
                  </div>
                )}
              </div>
              {selectedLocation.description && (
                <div className="md:col-span-2">
                  <p className="text-sm text-muted-foreground">{selectedLocation.description}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
