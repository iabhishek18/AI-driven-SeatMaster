export type SeatStatus = "available" | "selected" | "booked"
export type SeatCategory = "standard" | "premium"
export type BookingStep = "select-event" | "select-seats" | "checkout" | "success"
export type EventType = "cinema" | "train" | "bus" | "general"

export interface SeatType {
  id: string
  row: string
  number: string
  status: SeatStatus
  category: SeatCategory
  price: number
}

export interface Event {
  id: string
  name: string
  date: string
  time: string
  venue: string
  image: string
  type: EventType
}

export interface Booking {
  id: string
  eventName: string
  date: string
  time: string
  venue: string
  seats: string[]
  type: string
  image?: string
  status?: "upcoming" | "past" | "cancelled"
  createdAt: number // timestamp
  isNew?: boolean // Flag to track new bookings
}
