export interface User {
  id: string
  name: string
  email: string
  profileImage: string
  phone?: string
  address?: string
  preferences?: {
    notifications: boolean
    newsletter: boolean
    seatPreferences?: string
  }
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
}
