export interface BusRoute {
  id: string
  busNumber: string
  operator: string
  departureCity: string
  arrivalCity: string
  departureTime: string
  arrivalTime: string
  duration: string
  departureDate: string
  price: number
  amenities: string[]
  busType: string
  availableSeats: number
  totalSeats: number
  rating: number
  image: string
}

export interface TrainRoute {
  id: string
  trainNumber: string
  trainName: string
  departureCity: string
  arrivalCity: string
  departureTime: string
  arrivalTime: string
  duration: string
  departureDate: string
  price: {
    economy: number
    business: number
    firstClass: number
  }
  amenities: string[]
  trainType: string
  availableSeats: {
    economy: number
    business: number
    firstClass: number
  }
  totalSeats: {
    economy: number
    business: number
    firstClass: number
  }
  stops: string[]
  platform: string
  rating: number
  image: string
}

export type TrainClass = "economy" | "business" | "firstClass"
