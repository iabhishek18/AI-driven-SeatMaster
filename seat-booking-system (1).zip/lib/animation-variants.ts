// Animation variants for Framer Motion
export const cardHoverVariants = {
  initial: {
    scale: 1,
    boxShadow: "0px 0px 0px rgba(0, 0, 0, 0.1)",
    rotateX: 0,
    rotateY: 0,
    z: 0,
  },
  hover: {
    scale: 1.02,
    boxShadow: "0px 10px 20px rgba(0, 0, 0, 0.15)",
    rotateX: 5,
    rotateY: 5,
    z: 20,
  },
  tap: {
    scale: 0.98,
    rotateX: 0,
    rotateY: 0,
    z: 0,
  },
}

export const buttonHoverVariants = {
  initial: {
    scale: 1,
    boxShadow: "0px 0px 0px rgba(0, 0, 0, 0.1)",
    y: 0,
  },
  hover: {
    scale: 1.05,
    boxShadow: "0px 5px 10px rgba(0, 0, 0, 0.2)",
    y: -2,
  },
  tap: {
    scale: 0.95,
    boxShadow: "0px 2px 5px rgba(0, 0, 0, 0.1)",
    y: 0,
  },
}

export const seatHoverVariants = {
  initial: {
    scale: 1,
    boxShadow: "0px 0px 0px rgba(0, 0, 0, 0.1)",
    y: 0,
  },
  hover: {
    scale: 1.1,
    boxShadow: "0px 5px 10px rgba(0, 0, 0, 0.2)",
    y: -2,
  },
  selected: {
    scale: 1.05,
    boxShadow: "0px 5px 15px rgba(0, 0, 0, 0.3)",
    y: -3,
  },
}

export const pageTransitionVariants = {
  initial: {
    opacity: 0,
    y: 20,
    scale: 0.98,
  },
  animate: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      duration: 0.5,
      ease: [0.22, 1, 0.36, 1],
    },
  },
  exit: {
    opacity: 0,
    y: -20,
    scale: 0.98,
    transition: {
      duration: 0.3,
    },
  },
}

export const staggerChildrenVariants = {
  initial: { opacity: 0 },
  animate: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

export const childVariants = {
  initial: {
    opacity: 0,
    y: 20,
    rotateX: 10,
  },
  animate: {
    opacity: 1,
    y: 0,
    rotateX: 0,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 12,
    },
  },
}

export const floatingAnimation = {
  initial: { y: 0 },
  animate: {
    y: [0, -10, 0],
    transition: {
      duration: 3,
      repeat: Number.POSITIVE_INFINITY,
      repeatType: "reverse",
      ease: "easeInOut",
    },
  },
}
