// AI Service for handling various AI-powered features
export class AIService {
  private static instance: AIService
  private userPreferences: Map<string, any> = new Map()
  private userBehavior: Array<{ action: string; data: any; timestamp: number }> = []
  private contentCache: Map<string, any> = new Map()

  private constructor() {
    this.loadUserData()
  }

  static getInstance(): AIService {
    if (!AIService.instance) {
      AIService.instance = new AIService()
    }
    return AIService.instance
  }

  // Load user data from localStorage
  private loadUserData() {
    try {
      const preferences = localStorage.getItem("ai_user_preferences")
      const behavior = localStorage.getItem("ai_user_behavior")

      if (preferences) {
        this.userPreferences = new Map(JSON.parse(preferences))
      }

      if (behavior) {
        this.userBehavior = JSON.parse(behavior)
      }
    } catch (error) {
      console.error("Error loading user data:", error)
    }
  }

  // Save user data to localStorage
  private saveUserData() {
    try {
      localStorage.setItem("ai_user_preferences", JSON.stringify(Array.from(this.userPreferences.entries())))
      localStorage.setItem("ai_user_behavior", JSON.stringify(this.userBehavior))
    } catch (error) {
      console.error("Error saving user data:", error)
    }
  }

  // Track user behavior
  trackUserBehavior(action: string, data: any) {
    this.userBehavior.push({
      action,
      data,
      timestamp: Date.now(),
    })

    // Keep only last 1000 actions
    if (this.userBehavior.length > 1000) {
      this.userBehavior = this.userBehavior.slice(-1000)
    }

    this.saveUserData()
    this.updateUserPreferences(action, data)
  }

  // Update user preferences based on behavior
  private updateUserPreferences(action: string, data: any) {
    switch (action) {
      case "view_event":
        this.incrementPreference("event_types", data.type)
        this.incrementPreference("venues", data.venue)
        break
      case "book_event":
        this.incrementPreference("booked_event_types", data.type)
        this.incrementPreference("preferred_times", data.time)
        break
      case "view_venue":
        this.incrementPreference("viewed_venues", data.venue)
        break
      case "search":
        this.incrementPreference("search_terms", data.query)
        break
    }
  }

  private incrementPreference(category: string, value: string) {
    const current = this.userPreferences.get(category) || {}
    current[value] = (current[value] || 0) + 1
    this.userPreferences.set(category, current)
    this.saveUserData()
  }

  // Generate personalized recommendations
  generateRecommendations(events: any[], limit = 5): any[] {
    const eventTypes = this.userPreferences.get("event_types") || {}
    const venues = this.userPreferences.get("venues") || {}
    const bookedTypes = this.userPreferences.get("booked_event_types") || {}

    // Score events based on user preferences
    const scoredEvents = events.map((event) => {
      let score = 0

      // Prefer event types user has viewed
      score += (eventTypes[event.type] || 0) * 2

      // Prefer venues user has viewed
      score += (venues[event.venue] || 0) * 1.5

      // Highly prefer event types user has booked
      score += (bookedTypes[event.type] || 0) * 3

      // Add some randomness to avoid being too predictable
      score += Math.random() * 0.5

      return { ...event, aiScore: score }
    })

    // Sort by score and return top recommendations
    return scoredEvents.sort((a, b) => b.aiScore - a.aiScore).slice(0, limit)
  }

  // Generate dynamic content descriptions
  generateEventDescription(event: any): string {
    const templates = {
      cinema: [
        `Experience the magic of cinema at ${event.venue}. This ${event.name} promises an unforgettable movie experience with state-of-the-art sound and visuals.`,
        `Don't miss ${event.name} at ${event.venue}! Immerse yourself in this cinematic masterpiece with premium seating and crystal-clear projection.`,
        `Join us for ${event.name} - a must-see film showing at ${event.venue}. Perfect for movie enthusiasts looking for quality entertainment.`,
      ],
      general: [
        `Get ready for an amazing experience at ${event.venue}! ${event.name} is set to be an unforgettable event that you won't want to miss.`,
        `${event.name} at ${event.venue} promises to be spectacular. Join thousands of others for this incredible live experience.`,
        `Experience the excitement of ${event.name} live at ${event.venue}. This event is perfect for anyone looking for premium entertainment.`,
      ],
      train: [
        `Travel in comfort with ${event.name}. Departing from ${event.venue}, this journey offers scenic views and reliable transportation.`,
        `Book your seat on ${event.name} for a smooth and comfortable journey. ${event.venue} provides excellent facilities for travelers.`,
        `Experience premium travel with ${event.name}. Starting from ${event.venue}, enjoy a relaxing and efficient journey.`,
      ],
      bus: [
        `Convenient and affordable travel with ${event.name}. Departing from ${event.venue} with modern amenities and comfortable seating.`,
        `Choose ${event.name} for your next journey. ${event.venue} offers easy access and excellent facilities for all passengers.`,
        `Travel smart with ${event.name}. Starting from ${event.venue}, enjoy reliable transportation with great value.`,
      ],
    }

    const typeTemplates = templates[event.type as keyof typeof templates] || templates.general
    const randomTemplate = typeTemplates[Math.floor(Math.random() * typeTemplates.length)]

    return randomTemplate
  }

  // Generate smart search suggestions
  generateSearchSuggestions(query: string, events: any[]): string[] {
    const suggestions = new Set<string>()
    const lowerQuery = query.toLowerCase()

    // Add event names that match
    events.forEach((event) => {
      if (event.name.toLowerCase().includes(lowerQuery)) {
        suggestions.add(event.name)
      }
      if (event.venue.toLowerCase().includes(lowerQuery)) {
        suggestions.add(event.venue)
      }
      if (event.type.toLowerCase().includes(lowerQuery)) {
        suggestions.add(event.type)
      }
    })

    // Add popular search terms from user behavior
    const searchTerms = this.userPreferences.get("search_terms") || {}
    Object.keys(searchTerms).forEach((term) => {
      if (term.toLowerCase().includes(lowerQuery)) {
        suggestions.add(term)
      }
    })

    return Array.from(suggestions).slice(0, 5)
  }

  // Generate personalized venue recommendations
  generateVenueRecommendations(venues: string[]): string[] {
    const viewedVenues = this.userPreferences.get("viewed_venues") || {}
    const preferredVenues = this.userPreferences.get("venues") || {}

    // Score venues based on user interaction
    const scoredVenues = venues.map((venue) => {
      let score = 0
      score += (viewedVenues[venue] || 0) * 2
      score += (preferredVenues[venue] || 0) * 1.5
      score += Math.random() * 0.3 // Add randomness

      return { venue, score }
    })

    return scoredVenues
      .sort((a, b) => b.score - a.score)
      .map((item) => item.venue)
      .slice(0, 3)
  }

  // Generate smart notifications
  generateSmartNotifications(): Array<{ type: string; message: string; priority: number }> {
    const notifications = []
    const eventTypes = this.userPreferences.get("event_types") || {}
    const bookedTypes = this.userPreferences.get("booked_event_types") || {}

    // Suggest based on viewing patterns
    const mostViewedType = Object.keys(eventTypes).reduce(
      (a, b) => (eventTypes[a] > eventTypes[b] ? a : b),
      Object.keys(eventTypes)[0],
    )

    if (mostViewedType) {
      notifications.push({
        type: "recommendation",
        message: `New ${mostViewedType} events are available! Check out our latest ${mostViewedType} offerings.`,
        priority: 2,
      })
    }

    // Suggest completing bookings
    const recentViews = this.userBehavior
      .filter((b) => b.action === "view_event" && Date.now() - b.timestamp < 24 * 60 * 60 * 1000)
      .slice(-3)

    if (recentViews.length > 0) {
      notifications.push({
        type: "reminder",
        message: `Don't forget about the events you viewed recently. Book now before they sell out!`,
        priority: 3,
      })
    }

    return notifications.sort((a, b) => b.priority - a.priority)
  }

  // Get user insights for analytics
  getUserInsights() {
    const eventTypes = this.userPreferences.get("event_types") || {}
    const venues = this.userPreferences.get("venues") || {}
    const totalActions = this.userBehavior.length

    return {
      totalInteractions: totalActions,
      favoriteEventType: Object.keys(eventTypes).reduce((a, b) => (eventTypes[a] > eventTypes[b] ? a : b), "general"),
      favoriteVenue: Object.keys(venues).reduce((a, b) => (venues[a] > venues[b] ? a : b), "Unknown"),
      activityLevel: totalActions > 50 ? "high" : totalActions > 20 ? "medium" : "low",
      preferences: {
        eventTypes,
        venues,
      },
    }
  }

  // Clear user data (for privacy)
  clearUserData() {
    this.userPreferences.clear()
    this.userBehavior = []
    localStorage.removeItem("ai_user_preferences")
    localStorage.removeItem("ai_user_behavior")
  }
}

export const aiService = AIService.getInstance()
