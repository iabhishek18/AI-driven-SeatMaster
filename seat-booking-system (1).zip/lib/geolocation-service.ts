export interface LocationData {
  latitude: number
  longitude: number
  accuracy: number
  timestamp: number
  address?: string
}

export interface LocationPermissionStatus {
  granted: boolean
  denied: boolean
  prompt: boolean
}

export interface NearbyLocation {
  id: string
  name: string
  type: "venue" | "event" | "poi" | "transport"
  latitude: number
  longitude: number
  distance: number
  address: string
  rating?: number
  description?: string
}

class GeolocationService {
  private static instance: GeolocationService
  private currentLocation: LocationData | null = null
  private watchId: number | null = null
  private locationCallbacks: ((location: LocationData | null) => void)[] = []
  private permissionCallbacks: ((status: LocationPermissionStatus) => void)[] = []

  static getInstance(): GeolocationService {
    if (!GeolocationService.instance) {
      GeolocationService.instance = new GeolocationService()
    }
    return GeolocationService.instance
  }

  // Check if geolocation is supported
  isSupported(): boolean {
    return "geolocation" in navigator
  }

  // Get current permission status
  async getPermissionStatus(): Promise<LocationPermissionStatus> {
    if (!this.isSupported()) {
      return { granted: false, denied: true, prompt: false }
    }

    try {
      const permission = await navigator.permissions.query({ name: "geolocation" })
      return {
        granted: permission.state === "granted",
        denied: permission.state === "denied",
        prompt: permission.state === "prompt",
      }
    } catch (error) {
      // Fallback for browsers that don't support permissions API
      return { granted: false, denied: false, prompt: true }
    }
  }

  // Request location permission and get current location
  async getCurrentLocation(options?: PositionOptions): Promise<LocationData> {
    return new Promise((resolve, reject) => {
      if (!this.isSupported()) {
        reject(new Error("Geolocation is not supported by this browser"))
        return
      }

      const defaultOptions: PositionOptions = {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000, // 5 minutes
        ...options,
      }

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const locationData: LocationData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp,
          }

          // Try to get address from coordinates
          try {
            locationData.address = await this.reverseGeocode(locationData.latitude, locationData.longitude)
          } catch (error) {
            console.warn("Failed to get address:", error)
          }

          this.currentLocation = locationData
          this.notifyLocationCallbacks(locationData)
          resolve(locationData)
        },
        (error) => {
          let errorMessage = "Failed to get location"
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = "Location access denied by user"
              break
            case error.POSITION_UNAVAILABLE:
              errorMessage = "Location information unavailable"
              break
            case error.TIMEOUT:
              errorMessage = "Location request timed out"
              break
          }
          reject(new Error(errorMessage))
        },
        defaultOptions,
      )
    })
  }

  // Start watching location changes
  startWatching(options?: PositionOptions): void {
    if (!this.isSupported() || this.watchId !== null) {
      return
    }

    const defaultOptions: PositionOptions = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 60000, // 1 minute
      ...options,
    }

    this.watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const locationData: LocationData = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp,
        }

        try {
          locationData.address = await this.reverseGeocode(locationData.latitude, locationData.longitude)
        } catch (error) {
          console.warn("Failed to get address:", error)
        }

        this.currentLocation = locationData
        this.notifyLocationCallbacks(locationData)
      },
      (error) => {
        console.error("Location watching error:", error)
        this.notifyLocationCallbacks(null)
      },
      defaultOptions,
    )
  }

  // Stop watching location changes
  stopWatching(): void {
    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId)
      this.watchId = null
    }
  }

  // Get cached current location
  getCachedLocation(): LocationData | null {
    return this.currentLocation
  }

  // Calculate distance between two points using Haversine formula
  calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371 // Earth's radius in kilometers
    const dLat = this.toRadians(lat2 - lat1)
    const dLon = this.toRadians(lon2 - lon1)
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180)
  }

  // Reverse geocoding - convert coordinates to address
  private async reverseGeocode(latitude: number, longitude: number): Promise<string> {
    // Using a simple geocoding service (in production, use a proper service like Google Maps)
    try {
      const response = await fetch(
        `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`,
      )
      const data = await response.json()
      return data.locality || data.city || data.countryName || "Unknown location"
    } catch (error) {
      throw new Error("Failed to reverse geocode")
    }
  }

  // Find nearby locations
  findNearbyLocations(userLat: number, userLon: number, locations: any[], radiusKm = 10): NearbyLocation[] {
    return locations
      .map((location) => {
        // Convert venue data to coordinates (mock data for demo)
        const lat = this.getLocationCoordinates(location).latitude
        const lon = this.getLocationCoordinates(location).longitude
        const distance = this.calculateDistance(userLat, userLon, lat, lon)

        if (distance <= radiusKm) {
          return {
            id: location.id,
            name: location.name || location.venue,
            type: location.type || "venue",
            latitude: lat,
            longitude: lon,
            distance: Math.round(distance * 100) / 100,
            address: location.address || location.venue,
            rating: location.rating,
            description: location.description,
          }
        }
        return null
      })
      .filter(Boolean)
      .sort((a, b) => a!.distance - b!.distance) as NearbyLocation[]
  }

  // Mock function to get coordinates for venues (in production, store real coordinates)
  private getLocationCoordinates(location: any): { latitude: number; longitude: number } {
    // Mock coordinates based on venue names
    const mockCoordinates: { [key: string]: { latitude: number; longitude: number } } = {
      "Madison Square Garden": { latitude: 40.7505, longitude: -73.9934 },
      "Hollywood Bowl": { latitude: 34.1122, longitude: -118.3389 },
      "Red Rocks Amphitheatre": { latitude: 39.6654, longitude: -105.2057 },
      "Wembley Stadium": { latitude: 51.556, longitude: -0.2796 },
      "Sydney Opera House": { latitude: -33.8568, longitude: 151.2153 },
      "Royal Albert Hall": { latitude: 51.5009, longitude: -0.1773 },
      "Carnegie Hall": { latitude: 40.7651, longitude: -73.9799 },
      "Lincoln Center": { latitude: 40.7722, longitude: -73.9834 },
    }

    const venueName = location.venue || location.name
    return (
      mockCoordinates[venueName] || {
        latitude: 40.7128 + (Math.random() - 0.5) * 0.1,
        longitude: -74.006 + (Math.random() - 0.5) * 0.1,
      }
    )
  }

  // Subscribe to location updates
  onLocationChange(callback: (location: LocationData | null) => void): () => void {
    this.locationCallbacks.push(callback)
    return () => {
      this.locationCallbacks = this.locationCallbacks.filter((cb) => cb !== callback)
    }
  }

  // Subscribe to permission changes
  onPermissionChange(callback: (status: LocationPermissionStatus) => void): () => void {
    this.permissionCallbacks.push(callback)
    return () => {
      this.permissionCallbacks = this.permissionCallbacks.filter((cb) => cb !== callback)
    }
  }

  private notifyLocationCallbacks(location: LocationData | null): void {
    this.locationCallbacks.forEach((callback) => callback(location))
  }

  private notifyPermissionCallbacks(status: LocationPermissionStatus): void {
    this.permissionCallbacks.forEach((callback) => callback(status))
  }

  // Clear all data and stop watching
  reset(): void {
    this.stopWatching()
    this.currentLocation = null
    this.locationCallbacks = []
    this.permissionCallbacks = []
  }
}

export const geolocationService = GeolocationService.getInstance()
