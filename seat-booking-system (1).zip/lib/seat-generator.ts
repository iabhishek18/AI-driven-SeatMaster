import type { SeatType, EventType } from "@/types/booking"

export function generateSeatsForEventType(eventType: EventType): SeatType[] {
  switch (eventType) {
    case "cinema":
      return generateCinemaSeats()
    case "train":
      return generateTrainSeats()
    case "bus":
      return generateBusSeats()
    default:
      return generateDefaultSeats()
  }
}

function generateCinemaSeats(): SeatType[] {
  const rows = ["A", "B", "C", "D", "E", "F", "G", "H"]
  const seatsPerRow = 12
  const seats: SeatType[] = []

  rows.forEach((row) => {
    for (let i = 1; i <= seatsPerRow; i++) {
      const isPremium = row === "A" || row === "B"
      const isBooked = Math.random() < 0.3 // 30% chance of being booked

      seats.push({
        id: `${row}-${i}`,
        row,
        number: i.toString(),
        status: isBooked ? "booked" : "available",
        category: isPremium ? "premium" : "standard",
        price: isPremium ? 18 : 12,
      })
    }
  })

  return seats
}

function generateTrainSeats(): SeatType[] {
  const coaches = ["1", "2", "3"]
  const seatsPerCoach = 16
  const seats: SeatType[] = []

  coaches.forEach((coach) => {
    for (let i = 1; i <= seatsPerCoach; i++) {
      const isPremium = i <= 4 // First 4 seats in each coach are premium
      const isBooked = Math.random() < 0.4 // 40% chance of being booked

      seats.push({
        id: `${coach}-${i}`,
        row: coach,
        number: i.toString(),
        status: isBooked ? "booked" : "available",
        category: isPremium ? "premium" : "standard",
        price: isPremium ? 85 : 45,
      })
    }
  })

  return seats
}

function generateBusSeats(): SeatType[] {
  const rows = ["A", "B", "C", "D"]
  const seatsPerRow = 4 // 2 on each side
  const seats: SeatType[] = []

  rows.forEach((row) => {
    for (let i = 1; i <= seatsPerRow; i++) {
      const isPremium = row === "A" // First row is premium
      const isBooked = Math.random() < 0.35 // 35% chance of being booked

      seats.push({
        id: `${row}-${i}`,
        row,
        number: i.toString(),
        status: isBooked ? "booked" : "available",
        category: isPremium ? "premium" : "standard",
        price: isPremium ? 65 : 35,
      })
    }
  })

  return seats
}

function generateDefaultSeats(): SeatType[] {
  const rows = ["A", "B", "C", "D", "E", "F"]
  const seatsPerRow = 10
  const seats: SeatType[] = []

  rows.forEach((row) => {
    for (let i = 1; i <= seatsPerRow; i++) {
      const isPremium = row === "A" || row === "B"
      const isBooked = Math.random() < 0.25 // 25% chance of being booked

      seats.push({
        id: `${row}-${i}`,
        row,
        number: i.toString(),
        status: isBooked ? "booked" : "available",
        category: isPremium ? "premium" : "standard",
        price: isPremium ? 120 : 80,
      })
    }
  })

  return seats
}
