"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Calendar, MapPin, Users, Sparkles } from "lucide-react"
import EventSelector from "@/components/event-selector"
import { initialEvents } from "@/data/initial-data"
import type { Event } from "@/types/booking"
import { useRouter } from "next/navigation"
import AIRecommendations from "@/components/ai-recommendations"
import AISmartSearch from "@/components/ai-smart-search"
import AIInsightsDashboard from "@/components/ai-insights-dashboard"
import { aiService } from "@/lib/ai-service"

export default function HomePage() {
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null)
  const [searchResults, setSearchResults] = useState<Event[]>([])
  const [showSearchResults, setShowSearchResults] = useState(false)
  const router = useRouter()

  const handleEventSelect = (event: Event) => {
    aiService.trackUserBehavior("view_event", {
      eventId: event.id,
      type: event.type,
      venue: event.venue,
      name: event.name,
    })

    setSelectedEvent(event)
    // Store the event in sessionStorage for the booking page
    sessionStorage.setItem("selectedEvent", JSON.stringify(event))
    // Navigate to the booking page
    router.push("/booking")
  }

  const handleSearch = (query: string, results: Event[]) => {
    setSearchResults(results)
    setShowSearchResults(true)
  }

  const featuredEvents = initialEvents.slice(0, 3)

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/20">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="container mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <div className="flex items-center justify-center mb-4">
              <Sparkles className="h-8 w-8 text-primary mr-3" />
              <span className="text-sm font-medium text-primary bg-primary/10 px-3 py-1 rounded-full">
                AI-Powered Experience
              </span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-primary via-purple-600 to-primary bg-clip-text text-transparent">
              Smart Seat Booking
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Experience the future of event booking with AI-powered recommendations, smart search, and personalized
              experiences tailored just for you.
            </p>

            {/* AI Smart Search */}
            <div className="max-w-2xl mx-auto mb-8">
              <AISmartSearch
                onSearch={handleSearch}
                placeholder="Ask AI to find your perfect event..."
                className="w-full"
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-lg px-8 py-6 cursor-pointer" onClick={() => router.push("/events")}>
                Explore Events
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="text-lg px-8 py-6 cursor-pointer"
                onClick={() => router.push("/transport")}
              >
                Book Transportation
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/20 rounded-full blur-3xl"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl"></div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Search Results or Featured Events */}
            {showSearchResults ? (
              <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-3xl font-bold">Search Results</h2>
                  <Button variant="outline" onClick={() => setShowSearchResults(false)} className="cursor-pointer">
                    View All Events
                  </Button>
                </div>
                <EventSelector events={searchResults} onSelectEvent={handleEventSelect} />
              </motion.section>
            ) : (
              <>
                {/* Featured Events */}
                <motion.section
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="space-y-6"
                >
                  <h2 className="text-3xl font-bold text-center">Featured Events</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {featuredEvents.map((event, index) => (
                      <motion.div
                        key={event.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 + index * 0.1 }}
                      >
                        <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                          <div className="relative h-48 overflow-hidden">
                            <img
                              src={event.image || "/placeholder.svg"}
                              alt={event.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                              onError={(e) => {
                                e.currentTarget.src = `/placeholder.svg?height=400&width=600&query=${event.type}%20event`
                              }}
                            />
                            <div className="absolute top-2 right-2 bg-primary text-white text-xs px-2 py-1 rounded-full">
                              {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                            </div>
                          </div>
                          <CardContent className="p-4">
                            <h3 className="font-semibold mb-2 line-clamp-1">{event.name}</h3>
                            <div className="space-y-1 text-sm text-muted-foreground mb-3">
                              <div className="flex items-center">
                                <Calendar className="w-4 h-4 mr-2" />
                                {event.date}
                              </div>
                              <div className="flex items-center">
                                <MapPin className="w-4 h-4 mr-2" />
                                {event.venue}
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                              {aiService.generateEventDescription(event)}
                            </p>
                            <Button className="w-full cursor-pointer" onClick={() => handleEventSelect(event)}>
                              Book Now
                            </Button>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </motion.section>

                {/* All Events Section */}
                <motion.section
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between">
                    <h2 className="text-3xl font-bold">All Events</h2>
                    <Button variant="outline" onClick={() => router.push("/events")} className="cursor-pointer">
                      View All
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                  <EventSelector events={initialEvents.slice(3, 9)} onSelectEvent={handleEventSelect} />
                </motion.section>
              </>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* AI Recommendations */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
              <AIRecommendations onSelectEvent={handleEventSelect} />
            </motion.div>

            {/* AI Insights Dashboard */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.6 }}>
              <AIInsightsDashboard />
            </motion.div>

            {/* Quick Stats */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.8 }}>
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Platform Stats</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-primary" />
                        <span className="text-sm">Active Events</span>
                      </div>
                      <span className="font-medium">{initialEvents.length}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2 text-primary" />
                        <span className="text-sm">Venues</span>
                      </div>
                      <span className="font-medium">{new Set(initialEvents.map((e) => e.venue)).size}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Users className="h-4 w-4 mr-2 text-primary" />
                        <span className="text-sm">Happy Customers</span>
                      </div>
                      <span className="font-medium">10,000+</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}
