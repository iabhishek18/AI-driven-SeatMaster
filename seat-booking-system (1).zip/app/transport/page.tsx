import TransportBookingFlow from "@/components/transport-booking-flow"

export default function TransportPage() {
  return <TransportBookingFlow />
}
