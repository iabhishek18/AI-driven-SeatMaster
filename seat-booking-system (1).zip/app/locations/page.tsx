"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { MapPin, Navigation, Calendar, Shield, Locate } from "lucide-react"
import LocationPermission from "@/components/location-permission"
import LocationMap from "@/components/location-map"
import { geolocationService, type LocationData, type NearbyLocation } from "@/lib/geolocation-service"
import { initialEvents } from "@/data/initial-data"

export default function LocationsPage() {
  const [userLocation, setUserLocation] = useState<LocationData | null>(null)
  const [hasPermission, setHasPermission] = useState(false)
  const [selectedLocation, setSelectedLocation] = useState<NearbyLocation | null>(null)
  const [locationStats, setLocationStats] = useState({
    totalVenues: 0,
    nearbyEvents: 0,
    averageDistance: 0,
  })

  useEffect(() => {
    // Check initial permission status
    checkPermissionStatus()

    // Subscribe to location updates
    const unsubscribe = geolocationService.onLocationChange((location) => {
      setUserLocation(location)
      if (location) {
        updateLocationStats(location)
      }
    })

    return unsubscribe
  }, [])

  const checkPermissionStatus = async () => {
    const status = await geolocationService.getPermissionStatus()
    setHasPermission(status.granted)

    if (status.granted) {
      const cachedLocation = geolocationService.getCachedLocation()
      if (cachedLocation) {
        setUserLocation(cachedLocation)
        updateLocationStats(cachedLocation)
      }
    }
  }

  const updateLocationStats = (location: LocationData) => {
    const nearby = geolocationService.findNearbyLocations(
      location.latitude,
      location.longitude,
      initialEvents,
      25, // 25km radius for stats
    )

    const totalVenues = new Set(nearby.map((loc) => loc.name)).size
    const nearbyEvents = nearby.length
    const averageDistance = nearby.length > 0 ? nearby.reduce((sum, loc) => sum + loc.distance, 0) / nearby.length : 0

    setLocationStats({
      totalVenues,
      nearbyEvents,
      averageDistance: Math.round(averageDistance * 10) / 10,
    })
  }

  const handlePermissionGranted = () => {
    setHasPermission(true)
    checkPermissionStatus()
  }

  const handleLocationSelect = (location: NearbyLocation) => {
    setSelectedLocation(location)
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold">Explore Locations</h1>
        <p className="text-xl text-muted-foreground">Discover nearby venues and events based on your location</p>
      </div>

      {/* Permission Check */}
      {!hasPermission && (
        <div className="max-w-2xl mx-auto">
          <LocationPermission onPermissionGranted={handlePermissionGranted} showCard={true} />
        </div>
      )}

      {hasPermission && (
        <>
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <MapPin className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{locationStats.totalVenues}</p>
                    <p className="text-sm text-muted-foreground">Nearby Venues</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <Calendar className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{locationStats.nearbyEvents}</p>
                    <p className="text-sm text-muted-foreground">Nearby Events</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Navigation className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{locationStats.averageDistance}km</p>
                    <p className="text-sm text-muted-foreground">Average Distance</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <Tabs defaultValue="map" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="map">Interactive Map</TabsTrigger>
              <TabsTrigger value="settings">Location Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="map" className="space-y-6">
              <LocationMap onLocationSelect={handleLocationSelect} showSearch={true} showFilters={true} />
            </TabsContent>

            <TabsContent value="settings" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Current Location Info */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Locate className="h-5 w-5" />
                      <span>Current Location</span>
                    </CardTitle>
                    <CardDescription>Your current location information and accuracy</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {userLocation ? (
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{userLocation.address || "Location detected"}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Latitude:</span>
                            <p className="font-mono">{userLocation.latitude.toFixed(6)}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Longitude:</span>
                            <p className="font-mono">{userLocation.longitude.toFixed(6)}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Accuracy:</span>
                            <p>±{Math.round(userLocation.accuracy)}m</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Last Updated:</span>
                            <p>{new Date(userLocation.timestamp).toLocaleTimeString()}</p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-muted-foreground">No location data available</p>
                    )}
                  </CardContent>
                </Card>

                {/* Privacy & Settings */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Shield className="h-5 w-5" />
                      <span>Privacy & Settings</span>
                    </CardTitle>
                    <CardDescription>Manage your location preferences and privacy</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Location Tracking</p>
                          <p className="text-sm text-muted-foreground">Allow continuous location updates</p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            if (geolocationService.getCachedLocation()) {
                              geolocationService.startWatching()
                            }
                          }}
                        >
                          Enable
                        </Button>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">Clear Location Data</p>
                          <p className="text-sm text-muted-foreground">Remove stored location information</p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            geolocationService.reset()
                            setUserLocation(null)
                            setLocationStats({
                              totalVenues: 0,
                              nearbyEvents: 0,
                              averageDistance: 0,
                            })
                          }}
                        >
                          Clear
                        </Button>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-medium mb-2">Privacy Information</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Location data is stored locally on your device</li>
                        <li>• We don't share your location with third parties</li>
                        <li>• You can disable location services at any time</li>
                        <li>• Data is used only to enhance your experience</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  )
}
